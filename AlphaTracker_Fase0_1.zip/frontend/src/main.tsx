import React from "react";
import ReactDOM from "react-dom/client";
import {
  Activity,
  AlertTriangle,
  BarChart3,
  Database,
  Download,
  Filter,
  Play,
  RefreshCw,
  Search,
  Table2
} from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis
} from "recharts";
import "./styles.css";

const API_BASE = import.meta.env.VITE_API_BASE_URL ?? "http://localhost:8000";

type Protein = {
  id: number;
  name: string;
  accession: string | null;
  length: number | null;
  is_complete: boolean;
  score: number;
  score_components: Record<string, number>;
  summary: string | null;
  created_at: string;
  updated_at: string;
};

type Alert = {
  id: number;
  protein_id: number;
  score: number;
  reason: string;
  justification: string;
  evidence_statement: string;
  bases_consulted: string[];
  created_at: string;
};

type Stats = {
  proteins: number;
  complete_proteins: number;
  alerts: number;
  publications: number;
  average_score: number;
  top_organisms: { organism: string; count: number }[];
  recent_runs: {
    id: number;
    status: string;
    started_at: string;
    finished_at: string | null;
    counters: Record<string, number>;
  }[];
};

function App() {
  const [proteins, setProteins] = React.useState<Protein[]>([]);
  const [alerts, setAlerts] = React.useState<Alert[]>([]);
  const [stats, setStats] = React.useState<Stats | null>(null);
  const [query, setQuery] = React.useState("");
  const [minScore, setMinScore] = React.useState(50);
  const [completeOnly, setCompleteOnly] = React.useState(true);
  const [loading, setLoading] = React.useState(false);
  const [running, setRunning] = React.useState(false);

  const load = React.useCallback(async () => {
    setLoading(true);
    const params = new URLSearchParams({
      min_score: String(minScore),
      complete_only: String(completeOnly)
    });
    if (query.trim()) params.set("q", query.trim());
    try {
      const [proteinRes, alertRes, statsRes] = await Promise.all([
        fetch(`${API_BASE}/proteins?${params.toString()}`),
        fetch(`${API_BASE}/alerts`),
        fetch(`${API_BASE}/stats`)
      ]);
      setProteins(await proteinRes.json());
      setAlerts(await alertRes.json());
      setStats(await statsRes.json());
    } finally {
      setLoading(false);
    }
  }, [query, minScore, completeOnly]);

  React.useEffect(() => {
    load();
  }, [load]);

  async function runPipeline() {
    setRunning(true);
    try {
      await fetch(`${API_BASE}/pipeline/run-once`, { method: "POST" });
      await load();
    } finally {
      setRunning(false);
    }
  }

  const timeline = proteins.slice(0, 20).reverse().map((protein) => ({
    name: new Date(protein.created_at).toLocaleDateString(),
    score: protein.score
  }));

  const heatmapRows = proteins.slice(0, 12);

  return (
    <main className="shell">
      <header className="topbar">
        <div>
          <p className="eyebrow">ALPHA TRACKER</p>
          <h1>Structural Evidence Monitor</h1>
        </div>
        <div className="actions">
          <button className="iconButton" title="Refresh" onClick={load} disabled={loading}>
            <RefreshCw size={18} />
          </button>
          <button className="primaryButton" onClick={runPipeline} disabled={running}>
            <Play size={17} />
            {running ? "Running" : "Run"}
          </button>
        </div>
      </header>

      <section className="metrics">
        <Metric icon={<Database size={18} />} label="Proteins" value={stats?.proteins ?? 0} />
        <Metric icon={<Activity size={18} />} label="Complete" value={stats?.complete_proteins ?? 0} />
        <Metric icon={<AlertTriangle size={18} />} label="Alerts" value={stats?.alerts ?? 0} />
        <Metric icon={<BarChart3 size={18} />} label="Avg Score" value={stats?.average_score ?? 0} />
      </section>

      <section className="toolbar">
        <label className="searchBox">
          <Search size={17} />
          <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search proteins" />
        </label>
        <label className="scoreControl">
          <Filter size={17} />
          <span>{minScore}</span>
          <input
            type="range"
            min="0"
            max="100"
            value={minScore}
            onChange={(event) => setMinScore(Number(event.target.value))}
          />
        </label>
        <label className="toggle">
          <input
            type="checkbox"
            checked={completeOnly}
            onChange={(event) => setCompleteOnly(event.target.checked)}
          />
          <span>Complete</span>
        </label>
        <div className="exports">
          <a title="CSV" href={`${API_BASE}/exports/proteins.csv`}>
            <Download size={16} /> CSV
          </a>
          <a title="Excel" href={`${API_BASE}/exports/proteins.xlsx`}>
            <Download size={16} /> XLSX
          </a>
          <a title="JSON" href={`${API_BASE}/exports/proteins.json`}>
            <Download size={16} /> JSON
          </a>
        </div>
      </section>

      <section className="grid">
        <div className="panel ranking">
          <div className="panelHeader">
            <h2>Ranking</h2>
            <Table2 size={18} />
          </div>
          <div className="tableWrap">
            <table>
              <thead>
                <tr>
                  <th>Protein</th>
                  <th>Accession</th>
                  <th>Length</th>
                  <th>Score</th>
                </tr>
              </thead>
              <tbody>
                {proteins.map((protein) => (
                  <tr key={protein.id}>
                    <td>
                      <a href={`${API_BASE}/proteins/${protein.id}`} target="_blank" rel="noreferrer">
                        {protein.name}
                      </a>
                      <small>{protein.summary}</small>
                    </td>
                    <td>{protein.accession ?? "n/a"}</td>
                    <td>{protein.length ?? "n/a"}</td>
                    <td>
                      <Score value={protein.score} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="panel">
          <div className="panelHeader">
            <h2>Timeline</h2>
            <Activity size={18} />
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={timeline}>
              <CartesianGrid stroke="#dde3e5" strokeDasharray="3 3" />
              <XAxis dataKey="name" tick={{ fontSize: 11 }} />
              <YAxis domain={[0, 100]} tick={{ fontSize: 11 }} />
              <Tooltip />
              <Line type="monotone" dataKey="score" stroke="#1d6f78" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="panel">
          <div className="panelHeader">
            <h2>Organisms</h2>
            <BarChart3 size={18} />
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={stats?.top_organisms ?? []}>
              <CartesianGrid stroke="#dde3e5" strokeDasharray="3 3" />
              <XAxis dataKey="organism" tick={{ fontSize: 10 }} />
              <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
              <Tooltip />
              <Bar dataKey="count" fill="#2d7f5e" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="panel alerts">
          <div className="panelHeader">
            <h2>Alerts</h2>
            <AlertTriangle size={18} />
          </div>
          <div className="alertList">
            {alerts.slice(0, 6).map((alert) => (
              <article key={alert.id}>
                <strong>{alert.score.toFixed(1)}</strong>
                <p>{alert.reason}</p>
                <small>{alert.evidence_statement}</small>
              </article>
            ))}
          </div>
        </div>

        <div className="panel heatmap">
          <div className="panelHeader">
            <h2>Score Heatmap</h2>
            <BarChart3 size={18} />
          </div>
          <div className="heatRows">
            {heatmapRows.map((protein) => (
              <div className="heatRow" key={protein.id}>
                <span>{protein.name}</span>
                {Object.entries(protein.score_components).map(([key, value]) => (
                  <i
                    key={key}
                    title={`${key}: ${value.toFixed(2)}`}
                    style={{ backgroundColor: colorFor(value) }}
                  />
                ))}
              </div>
            ))}
          </div>
        </div>

        <div className="panel">
          <div className="panelHeader">
            <h2>Runs</h2>
            <RefreshCw size={18} />
          </div>
          <div className="runList">
            {(stats?.recent_runs ?? []).map((run) => (
              <div key={run.id}>
                <span>{run.status}</span>
                <small>{new Date(run.started_at).toLocaleString()}</small>
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}

function Metric({ icon, label, value }: { icon: React.ReactNode; label: string; value: number }) {
  return (
    <article className="metric">
      {icon}
      <span>{label}</span>
      <strong>{value}</strong>
    </article>
  );
}

function Score({ value }: { value: number }) {
  return (
    <span className="score">
      <span style={{ width: `${Math.max(4, value)}%` }} />
      <b>{value.toFixed(1)}</b>
    </span>
  );
}

function colorFor(value: number) {
  if (value >= 0.75) return "#246b51";
  if (value >= 0.5) return "#d49c3d";
  if (value > 0) return "#c45f4c";
  return "#dfe5e3";
}

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

