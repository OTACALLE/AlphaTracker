from datetime import datetime, timezone

from alphatracker.db.models import Organism, Protein, Publication
from alphatracker.pipeline.scoring import score_protein


def test_scoring_prioritizes_complete_human_structural_gap():
    publication = Publication(
        source="test",
        source_id="1",
        title="Novel human neurodegenerative cancer protein",
        published_date=datetime.now(timezone.utc),
    )
    protein = Protein(
        name="Novel protein",
        organism=Organism(scientific_name="Homo sapiens", is_human=True),
        sequence_hash="abc",
        length=200,
        is_complete=True,
    )
    result = score_protein(
        protein,
        publication,
        feature_types={"transmembrane"},
        evidence_statuses=["not_found", "not_found", "not_found", "not_found"],
    )
    assert result.score >= 70
    assert result.components["structural_gap"] == 1.0
    assert result.components["human_priority"] == 1.0


def test_scoring_suppresses_gap_when_structure_found():
    protein = Protein(name="Known protein", length=100, is_complete=True)
    result = score_protein(
        protein,
        None,
        feature_types=set(),
        evidence_statuses=["found"],
    )
    assert result.components["structural_gap"] == 0.0

