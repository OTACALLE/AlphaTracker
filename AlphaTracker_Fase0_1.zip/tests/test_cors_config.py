"""Tests for CORS origin resolution.

See ALPHATRACKER_RELATORIO_TECNICO.md §4.6: the API previously combined
allow_origins=["*"] with allow_credentials=True, which is both rejected by
browsers and an unsafe default. These tests pin down the replacement policy:
explicit origins always win, "development" gets a scoped localhost default,
and anything else fails closed (no origins, no credentials) rather than
falling back to a wildcard.
"""
from __future__ import annotations

from alphatracker.api.app import _resolve_cors_origins
from alphatracker.config import Settings


def _settings(**overrides) -> Settings:
    return Settings(**overrides)


def test_explicit_origins_take_precedence_in_any_environment():
    settings = _settings(cors_allow_origins="https://a.example.org, https://b.example.org", environment="production")
    origins, allow_credentials = _resolve_cors_origins(settings)
    assert origins == ["https://a.example.org", "https://b.example.org"]
    assert allow_credentials is True


def test_development_default_is_scoped_to_local_vite_server():
    settings = _settings(environment="development", cors_allow_origins=None)
    origins, allow_credentials = _resolve_cors_origins(settings)
    assert "http://localhost:5173" in origins
    assert "*" not in origins
    assert allow_credentials is True


def test_non_development_without_explicit_origins_fails_closed():
    settings = _settings(environment="production", cors_allow_origins=None)
    origins, allow_credentials = _resolve_cors_origins(settings)
    assert origins == []
    assert allow_credentials is False


def test_wildcard_and_credentials_are_never_combined():
    for environment in ("development", "production", "staging", ""):
        settings = _settings(environment=environment, cors_allow_origins=None)
        origins, allow_credentials = _resolve_cors_origins(settings)
        assert not (origins == ["*"] and allow_credentials is True)
