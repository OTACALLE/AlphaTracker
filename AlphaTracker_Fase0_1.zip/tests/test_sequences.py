from alphatracker.utils.sequences import (
    check_complete_protein,
    find_fragment_markers,
    normalize_protein_name,
    parse_fasta_blocks,
    sequence_hash,
)


def test_parse_fasta_blocks_extracts_sequence():
    text = ">P1 example protein\nMKTAYIAKQRQISFVKSHFSRQ\n"
    blocks = parse_fasta_blocks(text)
    assert blocks == [("P1 example protein", "MKTAYIAKQRQISFVKSHFSRQ")]


def test_complete_sequence_passes_basic_checks():
    result = check_complete_protein("MKTAYIAKQRQISFVKSHFSRQ")
    assert result.is_complete is True
    assert result.normalized_sequence == "MKTAYIAKQRQISFVKSHFSRQ"


def test_internal_stop_rejects_sequence():
    result = check_complete_protein("MKTAYIAKQ*RQISFVKSHFSRQ")
    assert result.is_complete is False
    assert "internal stop" in result.reason


def test_sequence_hash_is_stable_after_normalization():
    assert sequence_hash("MKT A") == sequence_hash("mkta")


def test_find_fragment_markers_detects_known_markers():
    assert find_fragment_markers("Partial sequence of a novel kinase") == ["partial"]
    assert set(find_fragment_markers("A fragment of the truncated protein")) == {"fragment", "truncated"}


def test_find_fragment_markers_does_not_match_substrings():
    # "partially" must not be mistaken for the "partial" marker.
    assert find_fragment_markers("The protein folds partially under stress") == []


def test_find_fragment_markers_returns_empty_for_no_context():
    assert find_fragment_markers(None) == []
    assert find_fragment_markers("") == []


def test_check_complete_protein_rejects_sequence_when_title_says_partial():
    # Regression test: previously the function *claimed* to check fragment markers
    # ("Fragment markers checked: fragment, partial, truncated") without actually
    # looking at any text -- see ALPHATRACKER_RELATORIO_TECNICO.md §4.2. A
    # sequence that is otherwise well-formed must now be rejected when the
    # publication text explicitly calls it partial/a fragment/truncated.
    result = check_complete_protein(
        "MKTAYIAKQRQISFVKSHFSRQ",
        context_text="Partial sequence of a novel human kinase",
    )
    assert result.is_complete is False
    assert "partial" in result.reason.lower()


def test_check_complete_protein_accepts_when_no_markers_present_in_context():
    result = check_complete_protein(
        "MKTAYIAKQRQISFVKSHFSRQ",
        context_text="Full-length characterization of a novel human kinase",
    )
    assert result.is_complete is True
    assert "none were found" in result.reason


def test_check_complete_protein_is_honest_when_no_context_was_supplied():
    # No context_text at all: the function must not claim a check happened.
    result = check_complete_protein("MKTAYIAKQRQISFVKSHFSRQ")
    assert result.is_complete is True
    assert "were not checked" in result.reason


def test_normalize_protein_name_collapses_whitespace_and_case():
    assert normalize_protein_name("  Uncharacterized   PROTEIN ") == normalize_protein_name("uncharacterized protein")

