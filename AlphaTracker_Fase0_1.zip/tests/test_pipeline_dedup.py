"""Regression tests for the Protein deduplication fix.

See ALPHATRACKER_RELATORIO_TECNICO.md §4.1: candidates with no recoverable
sequence (the common case, since PubMed abstracts are frequently absent and
FASTA blocks rarely appear in title/abstract text) were previously inserted as
a brand new `Protein` row on every pipeline run, because deduplication only
looked at `sequence_hash`. These tests pin down the fix: sequence_hash-based
dedup keeps working unchanged, and a publication_id + normalized-name fallback
now covers the no-sequence case.
"""
from __future__ import annotations

from unittest.mock import AsyncMock

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

import alphatracker.db.models as m
from alphatracker.db.session import Base
from alphatracker.pipeline.runner import PipelineRunner
from alphatracker.schemas import CandidateProtein, EvidenceResult, PublicationIn

COMPLETE_SEQUENCE = "MKTAYIAKQRQISFVKSHFSRQLEERLGLIEVQAPILSRVGDGTQDNLSGAEKAVQVKVKALPDAQFEVVHSLAKWKRQTLGQHDFSAGEGLYTHMKALRPDEDRLSPLHSVYVDQWDWELVMGDGERWNVDGAP"


@pytest.fixture()
def session():
    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(bind=engine)
    factory = sessionmaker(bind=engine, autoflush=False, autocommit=False, expire_on_commit=False)
    db = factory()
    try:
        yield db
    finally:
        db.close()


def _skipped(source: str) -> EvidenceResult:
    return EvidenceResult(source=source, status="skipped", message="mocked for test")


def _mock_evidence_network(runner: PipelineRunner) -> None:
    """Replace all outbound evidence lookups with instant, network-free mocks.

    Only needed for candidates whose sequence is complete: `process_candidate`
    returns before touching the network at all when there is no sequence, which
    is exactly the branch most of these tests exercise.
    """
    runner.alphafold.check_accession = AsyncMock(return_value=_skipped("alphafold_db"))
    runner.rcsb.check_accession = AsyncMock(return_value=_skipped("pdb"))
    runner.uniprot.check_accession = AsyncMock(return_value=_skipped("uniprot"))
    runner.repositories.search_all = AsyncMock(return_value=[])


def _publication(source_id: str = "1", title: str = "A novel protein is described in this study") -> PublicationIn:
    return PublicationIn(source="pubmed", source_id=source_id, title=title, abstract=None)


def _candidate(
    name: str = "Uncharacterized protein",
    sequence: str | None = None,
    accession: str | None = None,
    publication: PublicationIn | None = None,
) -> CandidateProtein:
    return CandidateProtein(
        name=name,
        organism=None,
        accession=accession,
        sequence=sequence,
        publication=publication or _publication(),
    )


@pytest.mark.asyncio
async def test_first_insertion_creates_exactly_one_protein(session):
    runner = PipelineRunner(session)
    protein = await runner.process_candidate(_candidate())
    assert protein is not None
    assert session.query(m.Protein).count() == 1


@pytest.mark.asyncio
async def test_second_insertion_of_the_same_candidate_reuses_the_row(session):
    runner = PipelineRunner(session)
    candidate = _candidate()
    first = await runner.process_candidate(candidate)
    second = await runner.process_candidate(candidate)
    assert first.id == second.id
    assert session.query(m.Protein).count() == 1
    # The publication itself was already deduplicated before this fix; confirm
    # the fix didn't regress that.
    assert session.query(m.Publication).count() == 1


@pytest.mark.asyncio
async def test_many_repeated_pipeline_runs_still_yield_a_single_row(session):
    """Simulates the real-world scenario: the same publication falling inside the
    lookback window of dozens of overlapping polling cycles."""
    runner = PipelineRunner(session)
    candidate = _candidate()
    ids = set()
    for _ in range(50):
        protein = await runner.process_candidate(candidate)
        ids.add(protein.id)
    assert ids == {next(iter(ids))}
    assert session.query(m.Protein).count() == 1


@pytest.mark.asyncio
async def test_candidates_without_a_sequence_are_deduplicated(session):
    """This is the exact bug reproduction from the audit: no sequence, no
    accession -- previously seq_hash was always None, so `existing` was always
    None, and a new Protein row was created every single time."""
    runner = PipelineRunner(session)
    candidate = _candidate(sequence=None, accession=None)
    assert candidate.sequence is None
    first = await runner.process_candidate(candidate)
    second = await runner.process_candidate(candidate)
    third = await runner.process_candidate(candidate)
    assert first.id == second.id == third.id
    assert first.is_complete is False
    assert session.query(m.Protein).count() == 1


@pytest.mark.asyncio
async def test_identical_candidates_from_different_publications_are_not_merged(session):
    runner = PipelineRunner(session)
    candidate_a = _candidate(publication=_publication(source_id="pub-1"))
    candidate_b = _candidate(publication=_publication(source_id="pub-2"))
    protein_a = await runner.process_candidate(candidate_a)
    protein_b = await runner.process_candidate(candidate_b)
    assert protein_a.id != protein_b.id
    assert session.query(m.Protein).count() == 2


@pytest.mark.asyncio
async def test_different_candidate_names_in_the_same_publication_are_not_merged(session):
    runner = PipelineRunner(session)
    publication = _publication(source_id="pub-1")
    candidate_a = _candidate(name="Protein Alpha", publication=publication)
    candidate_b = _candidate(name="Protein Beta", publication=publication)
    protein_a = await runner.process_candidate(candidate_a)
    protein_b = await runner.process_candidate(candidate_b)
    assert protein_a.id != protein_b.id
    assert session.query(m.Protein).count() == 2
    # ...but the publication itself is still a single row.
    assert session.query(m.Publication).count() == 1


@pytest.mark.asyncio
async def test_name_normalization_prevents_whitespace_and_case_duplicates(session):
    runner = PipelineRunner(session)
    publication = _publication(source_id="pub-1")
    candidate_a = _candidate(name="Uncharacterized protein", publication=publication)
    candidate_b = _candidate(name="  uncharacterized   PROTEIN  ", publication=publication)
    protein_a = await runner.process_candidate(candidate_a)
    protein_b = await runner.process_candidate(candidate_b)
    assert protein_a.id == protein_b.id
    assert session.query(m.Protein).count() == 1


@pytest.mark.asyncio
async def test_sequence_hash_dedup_still_takes_priority_when_a_sequence_exists(session):
    """The fallback path must never break the pre-existing sequence_hash dedup."""
    runner = PipelineRunner(session)
    _mock_evidence_network(runner)
    publication = _publication(source_id="pub-1")
    candidate_a = _candidate(name="Protein One", sequence=COMPLETE_SEQUENCE, publication=publication)
    # Different publication, different name, but the *same* sequence: sequence_hash
    # dedup should still recognize this as the same protein.
    candidate_b = _candidate(
        name="Protein One (alt title)", sequence=COMPLETE_SEQUENCE, publication=_publication(source_id="pub-2")
    )
    protein_a = await runner.process_candidate(candidate_a)
    protein_b = await runner.process_candidate(candidate_b)
    assert protein_a.id == protein_b.id
    assert session.query(m.Protein).count() == 1
    assert session.query(m.Sequence).count() == 1


@pytest.mark.asyncio
async def test_placeholder_is_upgraded_in_place_once_a_real_sequence_is_found(session):
    """A candidate first seen with no sequence, then later re-processed (e.g. after
    an NCBI accession lookup succeeds) with a real sequence, should upgrade the
    existing placeholder row rather than leave a duplicate behind."""
    runner = PipelineRunner(session)
    _mock_evidence_network(runner)
    publication = _publication(source_id="pub-1")
    placeholder_candidate = _candidate(name="Uncharacterized protein", sequence=None, publication=publication)
    placeholder = await runner.process_candidate(placeholder_candidate)
    assert placeholder.is_complete is False
    assert session.query(m.Protein).count() == 1
    assert session.query(m.Sequence).count() == 0

    upgraded_candidate = _candidate(
        name="Uncharacterized protein", sequence=COMPLETE_SEQUENCE, publication=publication
    )
    upgraded = await runner.process_candidate(upgraded_candidate)

    assert upgraded.id == placeholder.id
    assert upgraded.is_complete is True
    assert session.query(m.Protein).count() == 1
    # The upgrade must also record the newly-found sequence exactly once.
    assert session.query(m.Sequence).count() == 1
