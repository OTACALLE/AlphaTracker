from alphatracker.analysis.sequence import analyze_sequence


def test_sequence_analysis_reports_weight_and_composition():
    result = analyze_sequence("MKTAYIAKQRQISFVKSHFSRQ")
    assert result.length == 22
    assert result.molecular_weight > 0
    assert result.amino_acid_composition["K"] == 3


def test_sequence_analysis_detects_transmembrane_like_region():
    result = analyze_sequence("MKK" + "LLLLLLLLLLLLLLLLLLLLL" + "GSGSGSGS")
    feature_types = {feature["feature_type"] for feature in result.features}
    assert "transmembrane" in feature_types

