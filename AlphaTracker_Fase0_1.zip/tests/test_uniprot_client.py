"""Tests for UniProtClient.check_accession and its wiring into the evidence flow.

See ALPHATRACKER_RELATORIO_TECNICO.md §4.3: UniProtClient was fully implemented
but never called anywhere in the pipeline. These tests cover the new
`check_accession` method directly (mocked HTTP, no real network access) and
confirm PipelineRunner._check_structure_evidence now actually calls it.
"""
from __future__ import annotations

from unittest.mock import AsyncMock

import httpx
import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from alphatracker.crawlers.sequence_sources import UniProtClient
from alphatracker.db.models import Protein
from alphatracker.db.session import Base
from alphatracker.pipeline.runner import PipelineRunner
from alphatracker.schemas import EvidenceResult


def _http_status_error(status_code: int) -> httpx.HTTPStatusError:
    request = httpx.Request("GET", "https://rest.uniprot.org/uniprotkb/FAKE01.json")
    response = httpx.Response(status_code=status_code, request=request)
    return httpx.HTTPStatusError("error", request=request, response=response)


@pytest.mark.asyncio
async def test_check_accession_skipped_when_no_accession():
    client = UniProtClient()
    result = await client.check_accession(None)
    assert result.source == "uniprot"
    assert result.status == "skipped"


@pytest.mark.asyncio
async def test_check_accession_found():
    client = UniProtClient()
    client.client.get_json = AsyncMock(
        return_value={"primaryAccession": "P69905", "entryType": "UniProtKB reviewed (Swiss-Prot)"}
    )
    result = await client.check_accession("P69905")
    assert result.status == "found"
    assert result.identifier == "P69905"
    assert result.source == "uniprot"


@pytest.mark.asyncio
async def test_check_accession_not_found_on_404():
    client = UniProtClient()
    client.client.get_json = AsyncMock(side_effect=_http_status_error(404))
    result = await client.check_accession("NOTREAL1")
    assert result.status == "not_found"
    assert result.source == "uniprot"


@pytest.mark.asyncio
async def test_check_accession_inconclusive_on_server_error():
    client = UniProtClient()
    client.client.get_json = AsyncMock(side_effect=_http_status_error(503))
    result = await client.check_accession("P69905")
    assert result.status == "inconclusive"


@pytest.mark.asyncio
async def test_check_accession_inconclusive_on_network_error_and_never_raises():
    client = UniProtClient()
    client.client.get_json = AsyncMock(side_effect=httpx.ConnectTimeout("timed out"))
    # Must not raise: evidence lookups are never allowed to interrupt the pipeline.
    result = await client.check_accession("P69905")
    assert result.status == "inconclusive"
    assert "timed out" in result.message


@pytest.mark.asyncio
async def test_pipeline_runner_calls_uniprot_during_structure_evidence_check():
    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    Base.metadata.create_all(bind=engine)
    session = sessionmaker(bind=engine, expire_on_commit=False)()
    runner = PipelineRunner(session)

    runner.alphafold.check_accession = AsyncMock(return_value=EvidenceResult(source="alphafold_db", status="skipped"))
    runner.rcsb.check_accession = AsyncMock(return_value=EvidenceResult(source="pdb", status="skipped"))
    runner.uniprot.check_accession = AsyncMock(
        return_value=EvidenceResult(source="uniprot", status="found", identifier="P69905")
    )

    protein = Protein(name="Test protein", accession="P69905")
    results = await runner._check_structure_evidence(protein)

    runner.uniprot.check_accession.assert_awaited_once_with("P69905")
    sources = {result.source for result in results}
    assert "uniprot" in sources
    uniprot_result = next(r for r in results if r.source == "uniprot")
    assert uniprot_result.status == "found"
