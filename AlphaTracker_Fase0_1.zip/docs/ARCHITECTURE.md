# Alpha Tracker Architecture

Alpha Tracker is organized as a modular scientific evidence system.

## Runtime

- FastAPI serves the dashboard API.
- Celery workers run continuous monitoring jobs.
- Celery Beat schedules monitoring every `ALPHATRACKER_POLL_INTERVAL_MINUTES`.
- PostgreSQL stores normalized entities and audit trails.
- Redis is the broker/result backend.
- React renders the operational dashboard.

## Scientific Guardrail

The system only reports evidence status for queried public sources. The absence of public evidence in these sources is not proof that no model exists.

Required wording:

```text
No public evidence of a structural model or corresponding structural publication was found in the queried sources.
```

## Pipeline

1. Fetch recent publication metadata.
2. Parse candidate protein names, accessions, organisms, and FASTA blocks.
3. Retrieve missing FASTA from NCBI Protein when an accession is available.
4. Validate sequence completeness (length, alphabet, ambiguity, stop codons, and
   fragment-indicating language in the source text -- see "Completeness and
   Fragment Detection" below).
5. Query structural evidence sources: AlphaFold DB, PDB/RCSB, and UniProt.
6. Search repository evidence sources.
7. Analyze sequence features.
8. Score and persist candidates.
9. Generate alerts above threshold.

## Extending Connectors

Every connector should return one of:

- `found`: public evidence was found.
- `not_found`: lookup succeeded and no matching evidence was found.
- `inconclusive`: lookup failed or response could not be interpreted.
- `skipped`: connector was intentionally not run.

Do not convert `inconclusive` to `not_found`.

Structural evidence connectors (`AlphaFoldClient`, `RCSBClient`, `UniProtClient`)
all expose an accession-based `check_accession(accession) -> EvidenceResult`
method and never raise: any lookup failure is caught internally and reported as
`inconclusive`, so a connector failure never interrupts the pipeline.

## Completeness and Fragment Detection

`alphatracker.utils.sequences.check_complete_protein(sequence, context_text)`
checks, in order: minimum length, valid amino-acid alphabet, ambiguous-residue
ratio, internal stop codons, and finally whether `context_text` (publication
title + abstract + FASTA header, when available) explicitly describes the
sequence as a `fragment`, `partial`, or `truncated` sequence
(`find_fragment_markers`). A sequence is only marked complete when it passes
every check; the returned `reason` always reflects exactly what was checked --
including explicitly saying so when `context_text` was not supplied and the
fragment-marker check was therefore skipped.

## Protein Deduplication

`Protein` rows are deduplicated in `PipelineRunner.process_candidate` using two
keys, tried in order:

1. **`sequence_hash`** (primary): an exact match on the normalized, hashed
   sequence. Used whenever a candidate has a recoverable sequence.
2. **`publication_id` + `name_normalized`** (fallback): used whenever there is
   no `sequence_hash` to key on (most commonly because no sequence could be
   recovered for the candidate at all). `name_normalized` collapses whitespace
   and case so the same candidate name is recognized across runs even if
   extraction produced slightly different formatting.

When a fallback match already has a confirmed `sequence_hash`, it is never
reused for a candidate carrying a *different* sequence -- only sequence-less
placeholders are eligible for the fallback match, and are upgraded in place
(including inserting the `Sequence` row that was missing) the first time a real
sequence is found for them. Neither key is enforced as a database-level unique
constraint; both are applied as an app-level lookup-before-insert, consistent
with how `sequence_hash` dedup already worked before this fallback existed.

## CORS

`alphatracker.api.app._resolve_cors_origins` resolves the CORS policy per
`ALPHATRACKER_ENVIRONMENT`:

- If `ALPHATRACKER_CORS_ALLOW_ORIGINS` (comma-separated) is set, those origins
  are used with credentials allowed, in any environment.
- Otherwise, `development` (the default) allows the local Vite dashboard
  origins with credentials.
- Otherwise (any non-`development` environment, nothing explicitly
  configured), the policy fails closed: no origins allowed, no credentials.

A wildcard origin (`"*"`) is never combined with `allow_credentials=True`.

## Migrations

Schema changes are tracked with Alembic (`migrations/`), with
`migrations/env.py` reading `ALPHATRACKER_DATABASE_URL` via
`alphatracker.config.get_settings()`. `alembic upgrade head` is the source of
truth for schema setup in any environment, including production, and is safe
to run repeatedly. `Base.metadata.create_all()` (used by `alpha-tracker init-db`
and the API startup hook) still works for quick local/throwaway setups, but
does not version schema history the way Alembic migrations do -- prefer Alembic
for anything beyond local experimentation. Both the `upgrade` and `downgrade`
paths of every migration are expected to work; the initial baseline migration
explicitly drops the native PostgreSQL `ENUM` types it creates on downgrade,
since `DROP TABLE` alone does not remove them.


