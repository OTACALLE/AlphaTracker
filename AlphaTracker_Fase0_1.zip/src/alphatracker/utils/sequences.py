from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass

VALID_AA = set("ACDEFGHIKLMNPQRSTVWY")
AMBIGUOUS_AA = set("BXZJUO")
STOP = "*"

FASTA_RE = re.compile(r"(?m)^>(?P<header>[^\n\r]+)\r?\n(?P<body>(?:[A-Za-z*.-]+\s*)+)")
ACCESSION_RE = re.compile(r"\b(?:[OPQ][0-9][A-Z0-9]{3}[0-9]|[A-NR-Z][0-9][A-Z][A-Z0-9]{2}[0-9])\b")

# Markers that, when present in the text describing a candidate (title, abstract,
# FASTA header), indicate the underlying sequence is explicitly reported as a
# fragment rather than a complete protein. Matched as whole words so "partial"
# does not spuriously match inside words like "partially".
FRAGMENT_MARKERS: tuple[str, ...] = ("fragment", "partial", "truncated")
_FRAGMENT_MARKER_PATTERNS = {marker: re.compile(rf"\b{re.escape(marker)}\b", re.IGNORECASE) for marker in FRAGMENT_MARKERS}


@dataclass(frozen=True)
class CompletenessCheck:
    is_complete: bool
    reason: str
    normalized_sequence: str


def normalize_sequence(sequence: str) -> str:
    return re.sub(r"[^A-Za-z*]", "", sequence).upper()


def sequence_hash(sequence: str) -> str:
    return hashlib.sha256(normalize_sequence(sequence).encode("ascii")).hexdigest()


def parse_fasta_blocks(text: str) -> list[tuple[str, str]]:
    blocks: list[tuple[str, str]] = []
    for match in FASTA_RE.finditer(text or ""):
        header = match.group("header").strip()
        seq = normalize_sequence(match.group("body"))
        if seq:
            blocks.append((header, seq))
    return blocks


def extract_accessions(text: str) -> list[str]:
    return sorted(set(ACCESSION_RE.findall(text or "")))


def find_fragment_markers(text: str | None) -> list[str]:
    """Return which fragment-indicating markers (see FRAGMENT_MARKERS) appear in `text`.

    `text` is expected to be the free text describing the candidate (publication
    title/abstract and/or FASTA header) -- not the amino-acid sequence itself, which
    never contains English words like "partial". Returns an empty list when `text`
    is falsy or none of the markers are present.
    """
    if not text:
        return []
    return [marker for marker, pattern in _FRAGMENT_MARKER_PATTERNS.items() if pattern.search(text)]


def normalize_protein_name(name: str) -> str:
    """Normalize a protein name for identity comparisons across pipeline runs.

    Collapses internal whitespace, strips leading/trailing whitespace, and
    case-folds, so the same candidate extracted with slightly different spacing
    or capitalization on two different runs is still recognized as the same name.
    """
    return re.sub(r"\s+", " ", name or "").strip().casefold()


def check_complete_protein(sequence: str | None, context_text: str | None = None) -> CompletenessCheck:
    """Check whether `sequence` looks like a complete amino-acid sequence.

    `context_text` is optional free text (e.g. publication title + abstract +
    FASTA header) that is scanned for fragment-indicating language ("fragment",
    "partial", "truncated"). This is a real check against that text -- it is only
    skipped, and honestly reported as skipped, when no `context_text` is supplied.
    """
    if not sequence:
        return CompletenessCheck(False, "No amino-acid sequence was available.", "")

    seq = normalize_sequence(sequence)
    if len(seq) < 16:
        return CompletenessCheck(False, "Sequence is shorter than 16 amino acids.", seq)
    if seq.endswith(STOP):
        seq = seq[:-1]
    if STOP in seq:
        return CompletenessCheck(False, "Sequence contains an internal stop codon marker.", seq)
    invalid = set(seq) - VALID_AA - AMBIGUOUS_AA
    if invalid:
        return CompletenessCheck(False, f"Sequence contains invalid amino-acid symbols: {sorted(invalid)}.", seq)
    ambiguous_count = sum(1 for aa in seq if aa in AMBIGUOUS_AA)
    if ambiguous_count / len(seq) > 0.05:
        return CompletenessCheck(False, "More than 5% of residues are ambiguous.", seq)

    found_markers = find_fragment_markers(context_text)
    if found_markers:
        return CompletenessCheck(
            False,
            "Sequence passes length, alphabet, ambiguity, and stop-codon checks, but the source text "
            f"explicitly describes it as a fragment (marker(s) found: {', '.join(found_markers)}).",
            seq,
        )

    reason = "Sequence passes length, alphabet, ambiguity, and stop-codon checks."
    if context_text is not None:
        reason += f" Fragment markers ({', '.join(FRAGMENT_MARKERS)}) were checked against the source text and none were found."
    else:
        reason += " Fragment markers were not checked because no source text was supplied."
    return CompletenessCheck(True, reason, seq)

