from __future__ import annotations

from datetime import datetime, timezone

from alphatracker.db.models import Protein, Publication
from alphatracker.schemas import ScoreResult

DISEASE_TERMS = {
    "cancer",
    "tumor",
    "tumour",
    "alzheimer",
    "parkinson",
    "amyotrophic lateral sclerosis",
    "als",
    "ela",
    "psp",
    "progressive supranuclear palsy",
    "tauopathy",
    "tau",
    "neurodegenerative",
}

BIOMEDICAL_TERMS = {
    "brain",
    "neuron",
    "neuronal",
    "nervous system",
    "developmental",
    "synapse",
    "immune",
    "inflammation",
}

PHARMA_FEATURES = {"transmembrane", "signal_peptide"}


def score_protein(
    protein: Protein,
    publication: Publication | None,
    feature_types: set[str],
    evidence_statuses: list[str],
) -> ScoreResult:
    text = " ".join(
        filter(None, [protein.name, publication.title if publication else None, publication.abstract if publication else None])
    ).lower()
    structural_found = any(status == "found" for status in evidence_statuses)
    inconclusive_count = sum(status == "inconclusive" for status in evidence_statuses)
    not_found_count = sum(status == "not_found" for status in evidence_statuses)

    components = {
        "novelty": _novelty(protein, structural_found),
        "recency": _recency(publication),
        "sequence_confidence": 1.0 if protein.is_complete and protein.length else 0.0,
        "structural_gap": 0.0 if structural_found else min(1.0, not_found_count / 4),
        "human_priority": 1.0 if protein.organism and protein.organism.is_human else 0.0,
        "disease_relevance": _term_score(text, DISEASE_TERMS),
        "biomedical_importance": _term_score(text, BIOMEDICAL_TERMS),
        "pharmacological_potential": 1.0 if feature_types & PHARMA_FEATURES else 0.2 if feature_types else 0.0,
        "evidence_quality": max(0.0, 1.0 - inconclusive_count * 0.15),
    }
    weights = {
        "novelty": 20,
        "recency": 15,
        "sequence_confidence": 15,
        "structural_gap": 15,
        "human_priority": 10,
        "disease_relevance": 10,
        "biomedical_importance": 8,
        "pharmacological_potential": 5,
        "evidence_quality": 2,
    }
    score = sum(weights[key] * components[key] for key in weights)
    score = max(0.0, min(100.0, score))
    justification = _justify(score, components, structural_found)
    return ScoreResult(score=round(score, 2), components=components, justification=justification)


def _novelty(protein: Protein, structural_found: bool) -> float:
    if structural_found:
        return 0.2
    if protein.accession:
        return 0.7
    if protein.sequence_hash:
        return 0.85
    return 0.4


def _recency(publication: Publication | None) -> float:
    if not publication or not publication.published_date:
        return 0.4
    age_days = (datetime.now(timezone.utc) - publication.published_date).days
    if age_days <= 7:
        return 1.0
    if age_days <= 30:
        return 0.8
    if age_days <= 180:
        return 0.5
    return 0.2


def _term_score(text: str, terms: set[str]) -> float:
    hits = sum(1 for term in terms if term in text)
    if hits == 0:
        return 0.0
    return min(1.0, hits / 3)


def _justify(score: float, components: dict[str, float], structural_found: bool) -> str:
    if structural_found:
        return "Structural evidence was found, so the structural-gap component is suppressed."
    strengths = [key for key, value in components.items() if value >= 0.75]
    return (
        f"Score {score:.1f}/100 driven by "
        f"{', '.join(strengths) if strengths else 'moderate evidence across components'}."
    )

