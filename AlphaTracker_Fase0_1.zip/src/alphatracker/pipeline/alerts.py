from __future__ import annotations

EVIDENCE_STATEMENT = (
    "No public evidence of a structural model or corresponding structural publication was found "
    "in the queried sources."
)


def alert_reason(score: float, structural_evidence_found: bool) -> str:
    if structural_evidence_found:
        return "Candidate has public structural evidence and is retained for tracking, but not prioritized as a gap."
    if score >= 85:
        return "High-priority candidate with complete sequence and no public structural evidence found."
    if score >= 70:
        return "Promising candidate with complete sequence and no public structural evidence found."
    return "Candidate retained below alert threshold."

