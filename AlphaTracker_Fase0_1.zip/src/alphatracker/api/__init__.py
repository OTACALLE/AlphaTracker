"""FastAPI application."""

