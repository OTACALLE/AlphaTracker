from __future__ import annotations

import io

import pandas as pd
from fastapi import APIRouter, Depends, HTTPException, Query, Response
from sqlalchemy import desc, func, select
from sqlalchemy.orm import Session, selectinload

from alphatracker.db.models import Alert, Organism, PipelineRun, Protein, Publication
from alphatracker.db.session import get_session
from alphatracker.pipeline.runner import PipelineRunner
from alphatracker.schemas import AlertOut, ProteinOut

router = APIRouter()


@router.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@router.post("/pipeline/run-once")
async def run_once(
    lookback_days: int | None = Query(default=None, ge=1, le=90),
    session: Session = Depends(get_session),
) -> dict[str, int]:
    return await PipelineRunner(session).run_once(lookback_days=lookback_days)


@router.get("/proteins", response_model=list[ProteinOut])
def list_proteins(
    min_score: float | None = Query(default=None, ge=0, le=100),
    complete_only: bool = False,
    q: str | None = None,
    limit: int = Query(default=100, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    session: Session = Depends(get_session),
) -> list[Protein]:
    stmt = select(Protein).order_by(desc(Protein.score), desc(Protein.created_at))
    if min_score is not None:
        stmt = stmt.where(Protein.score >= min_score)
    if complete_only:
        stmt = stmt.where(Protein.is_complete.is_(True))
    if q:
        stmt = stmt.where(Protein.name.ilike(f"%{q}%"))
    return list(session.scalars(stmt.offset(offset).limit(limit)).all())


@router.get("/proteins/{protein_id}")
def get_protein(protein_id: int, session: Session = Depends(get_session)) -> dict:
    protein = session.scalar(
        select(Protein)
        .where(Protein.id == protein_id)
        .options(
            selectinload(Protein.publication),
            selectinload(Protein.organism),
            selectinload(Protein.sequences),
            selectinload(Protein.features),
            selectinload(Protein.structure_evidence),
            selectinload(Protein.literature_evidence),
            selectinload(Protein.repository_evidence),
            selectinload(Protein.alerts),
        )
    )
    if not protein:
        raise HTTPException(status_code=404, detail="Protein not found")
    return {
        "id": protein.id,
        "name": protein.name,
        "accession": protein.accession,
        "organism": protein.organism.scientific_name if protein.organism else None,
        "length": protein.length,
        "is_complete": protein.is_complete,
        "completeness_reason": protein.completeness_reason,
        "score": protein.score,
        "score_components": protein.score_components,
        "summary": protein.summary,
        "publication": _publication_dict(protein.publication),
        "sequence": protein.sequences[0].sequence if protein.sequences else None,
        "features": [_feature_dict(item) for item in protein.features],
        "structure_evidence": [_evidence_dict(item) for item in protein.structure_evidence],
        "literature_evidence": [_literature_dict(item) for item in protein.literature_evidence],
        "repository_evidence": [_repo_dict(item) for item in protein.repository_evidence],
        "alerts": [AlertOut.model_validate(item).model_dump(mode="json") for item in protein.alerts],
    }


@router.get("/alerts", response_model=list[AlertOut])
def list_alerts(
    limit: int = Query(default=100, ge=1, le=500),
    session: Session = Depends(get_session),
) -> list[Alert]:
    stmt = select(Alert).order_by(desc(Alert.score), desc(Alert.created_at)).limit(limit)
    return list(session.scalars(stmt).all())


@router.get("/stats")
def stats(session: Session = Depends(get_session)) -> dict:
    total = session.scalar(select(func.count(Protein.id))) or 0
    complete = session.scalar(select(func.count(Protein.id)).where(Protein.is_complete.is_(True))) or 0
    alerts = session.scalar(select(func.count(Alert.id))) or 0
    publications = session.scalar(select(func.count(Publication.id))) or 0
    avg_score = session.scalar(select(func.avg(Protein.score))) or 0
    by_organism = session.execute(
        select(Organism.scientific_name, func.count(Protein.id))
        .join(Protein, Protein.organism_id == Organism.id)
        .group_by(Organism.scientific_name)
        .order_by(desc(func.count(Protein.id)))
        .limit(10)
    ).all()
    runs = session.scalars(select(PipelineRun).order_by(desc(PipelineRun.started_at)).limit(10)).all()
    return {
        "proteins": total,
        "complete_proteins": complete,
        "alerts": alerts,
        "publications": publications,
        "average_score": round(float(avg_score), 2),
        "top_organisms": [{"organism": item[0], "count": item[1]} for item in by_organism],
        "recent_runs": [
            {
                "id": run.id,
                "source": run.source,
                "status": run.status,
                "started_at": run.started_at.isoformat(),
                "finished_at": run.finished_at.isoformat() if run.finished_at else None,
                "counters": run.counters,
            }
            for run in runs
        ],
    }


@router.get("/exports/proteins.{fmt}")
def export_proteins(fmt: str, session: Session = Depends(get_session)) -> Response:
    rows = []
    proteins = session.scalars(
        select(Protein)
        .options(selectinload(Protein.publication), selectinload(Protein.organism))
        .order_by(desc(Protein.score))
    ).all()
    for protein in proteins:
        rows.append(
            {
                "id": protein.id,
                "name": protein.name,
                "organism": protein.organism.scientific_name if protein.organism else None,
                "accession": protein.accession,
                "length": protein.length,
                "is_complete": protein.is_complete,
                "score": protein.score,
                "doi": protein.publication.doi if protein.publication else None,
                "journal": protein.publication.journal if protein.publication else None,
                "publication_date": protein.publication.published_date.isoformat()
                if protein.publication and protein.publication.published_date
                else None,
                "evidence_statement": (
                    "No public evidence of a structural model or corresponding structural publication was found "
                    "in the queried sources."
                ),
            }
        )
    frame = pd.DataFrame(rows)
    if fmt == "csv":
        return Response(frame.to_csv(index=False), media_type="text/csv")
    if fmt == "json":
        return Response(frame.to_json(orient="records"), media_type="application/json")
    if fmt in {"xlsx", "excel"}:
        buffer = io.BytesIO()
        with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
            frame.to_excel(writer, index=False, sheet_name="proteins")
        return Response(
            buffer.getvalue(),
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": "attachment; filename=alpha-tracker-proteins.xlsx"},
        )
    raise HTTPException(status_code=400, detail="Unsupported export format")


def _publication_dict(publication: Publication | None) -> dict | None:
    if not publication:
        return None
    return {
        "id": publication.id,
        "source": publication.source,
        "source_id": publication.source_id,
        "doi": publication.doi,
        "title": publication.title,
        "abstract": publication.abstract,
        "journal": publication.journal,
        "published_date": publication.published_date.isoformat() if publication.published_date else None,
        "url": publication.url,
    }


def _feature_dict(feature) -> dict:
    return {
        "feature_type": feature.feature_type,
        "name": feature.name,
        "start": feature.start,
        "end": feature.end,
        "score": feature.score,
        "metadata": feature.metadata_json,
    }


def _evidence_dict(item) -> dict:
    return {
        "source": item.source,
        "status": item.status.value,
        "method": item.method,
        "identifier": item.identifier,
        "url": item.url,
        "confidence": item.confidence,
        "message": item.message,
        "checked_at": item.checked_at.isoformat(),
    }


def _literature_dict(item) -> dict:
    return {
        "source": item.source,
        "query": item.query,
        "status": item.status.value,
        "title": item.title,
        "doi": item.doi,
        "url": item.url,
        "checked_at": item.checked_at.isoformat(),
    }


def _repo_dict(item) -> dict:
    return {
        "source": item.source,
        "query": item.query,
        "status": item.status.value,
        "identifier": item.identifier,
        "url": item.url,
        "checked_at": item.checked_at.isoformat(),
    }
