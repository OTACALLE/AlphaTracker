from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from alphatracker.api.routes import router
from alphatracker.config import Settings, get_settings
from alphatracker.db.session import create_all
from alphatracker.logging import configure_logging, get_logger

logger = get_logger(__name__)


def _resolve_cors_origins(settings: Settings) -> tuple[list[str], bool]:
    """Resolve the CORS allow-list and credentials flag for the current environment.

    Never combine a wildcard origin with allow_credentials=True: browsers reject
    that combination outright, and it is an unsafe default for an API that exposes
    write endpoints (e.g. POST /pipeline/run-once) -- see
    ALPHATRACKER_RELATORIO_TECNICO.md §4.6.
    """
    if settings.cors_allow_origins:
        origins = [origin.strip() for origin in settings.cors_allow_origins.split(",") if origin.strip()]
        return origins, True
    if settings.environment == "development":
        # Matches the Vite dev server started by docker-compose / `npm run dev`.
        return ["http://localhost:5173", "http://127.0.0.1:5173"], True
    logger.warning(
        "cors_no_explicit_origins_configured",
        environment=settings.environment,
        message="No ALPHATRACKER_CORS_ALLOW_ORIGINS configured outside development; failing closed (no origins allowed).",
    )
    return [], False


def create_app() -> FastAPI:
    configure_logging()
    settings = get_settings()
    app = FastAPI(
        title="Alpha Tracker API",
        version="0.1.0",
        description=(
            "Scientific monitoring API for complete protein sequences without public structural evidence "
            "in queried sources."
        ),
    )
    origins, allow_credentials = _resolve_cors_origins(settings)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins,
        allow_credentials=allow_credentials,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.on_event("startup")
    def startup() -> None:
        create_all()

    app.include_router(router)
    return app

