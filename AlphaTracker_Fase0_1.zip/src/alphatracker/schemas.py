from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class PublicationIn(BaseModel):
    source: str
    source_id: str | None = None
    doi: str | None = None
    title: str
    abstract: str | None = None
    journal: str | None = None
    published_date: datetime | None = None
    url: str | None = None
    authors: list[str] = Field(default_factory=list)
    raw_metadata: dict = Field(default_factory=dict)


class CandidateProtein(BaseModel):
    name: str
    organism: str | None = None
    accession: str | None = None
    fasta_header: str | None = None
    sequence: str | None = None
    sequence_source: str = "publication"
    publication: PublicationIn
    evidence_hints: dict = Field(default_factory=dict)


class EvidenceResult(BaseModel):
    source: str
    status: str
    method: str | None = None
    identifier: str | None = None
    url: str | None = None
    confidence: float = 0.0
    message: str | None = None
    raw_response: dict = Field(default_factory=dict)


class SequenceAnalysisResult(BaseModel):
    molecular_weight: float
    length: int
    amino_acid_composition: dict[str, int]
    features: list[dict] = Field(default_factory=list)
    metadata: dict = Field(default_factory=dict)


class ScoreResult(BaseModel):
    score: float
    components: dict[str, float]
    justification: str


class ProteinOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    accession: str | None
    length: int | None
    is_complete: bool
    score: float
    score_components: dict
    summary: str | None
    created_at: datetime
    updated_at: datetime


class AlertOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    protein_id: int
    score: float
    reason: str
    justification: str
    evidence_statement: str
    bases_consulted: list
    created_at: datetime

