from __future__ import annotations

from collections import Counter

from alphatracker.schemas import SequenceAnalysisResult
from alphatracker.utils.sequences import normalize_sequence

AA_WEIGHTS = {
    "A": 89.09,
    "R": 174.20,
    "N": 132.12,
    "D": 133.10,
    "C": 121.16,
    "E": 147.13,
    "Q": 146.15,
    "G": 75.07,
    "H": 155.16,
    "I": 131.18,
    "L": 131.18,
    "K": 146.19,
    "M": 149.21,
    "F": 165.19,
    "P": 115.13,
    "S": 105.09,
    "T": 119.12,
    "W": 204.23,
    "Y": 181.19,
    "V": 117.15,
}

HYDROPHOBIC = set("AILMFWV")
DISORDER_PROMOTING = set("APQSGEKR")
LOW_COMPLEXITY_WINDOW = 20


def analyze_sequence(sequence: str) -> SequenceAnalysisResult:
    seq = normalize_sequence(sequence)
    composition = dict(Counter(seq))
    molecular_weight = _molecular_weight(seq)
    features = []
    features.extend(_low_complexity(seq))
    features.extend(_transmembrane(seq))
    features.extend(_signal_peptide(seq))
    features.extend(_coiled_coils(seq))
    features.extend(_disorder(seq))
    metadata = {
        "cellular_location_prediction": _cellular_location(seq, features),
        "domain_analysis_status": "InterPro-ready; persisted connector can enrich entries by accession.",
    }
    return SequenceAnalysisResult(
        molecular_weight=round(molecular_weight, 2),
        length=len(seq),
        amino_acid_composition=composition,
        features=features,
        metadata=metadata,
    )


def _molecular_weight(seq: str) -> float:
    if not seq:
        return 0.0
    total = sum(AA_WEIGHTS.get(aa, 0.0) for aa in seq)
    water_loss = 18.015 * max(len(seq) - 1, 0)
    return total - water_loss


def _low_complexity(seq: str) -> list[dict]:
    features = []
    for start in range(0, max(len(seq) - LOW_COMPLEXITY_WINDOW + 1, 0)):
        window = seq[start : start + LOW_COMPLEXITY_WINDOW]
        most_common = Counter(window).most_common(1)[0][1]
        if most_common / LOW_COMPLEXITY_WINDOW >= 0.45:
            features.append(
                {
                    "feature_type": "low_complexity",
                    "name": "Low complexity region",
                    "start": start + 1,
                    "end": start + LOW_COMPLEXITY_WINDOW,
                    "score": most_common / LOW_COMPLEXITY_WINDOW,
                }
            )
    return _merge_overlaps(features)


def _transmembrane(seq: str) -> list[dict]:
    features = []
    window = 21
    for start in range(0, max(len(seq) - window + 1, 0)):
        fragment = seq[start : start + window]
        ratio = sum(aa in HYDROPHOBIC for aa in fragment) / window
        if ratio >= 0.72:
            features.append(
                {
                    "feature_type": "transmembrane",
                    "name": "Hydrophobic transmembrane-like helix",
                    "start": start + 1,
                    "end": start + window,
                    "score": ratio,
                }
            )
    return _merge_overlaps(features)


def _signal_peptide(seq: str) -> list[dict]:
    nterm = seq[:30]
    if len(nterm) < 18:
        return []
    hydrophobic_core = max(
        (sum(aa in HYDROPHOBIC for aa in nterm[i : i + 12]) / 12 for i in range(0, len(nterm) - 11)),
        default=0.0,
    )
    has_basic_nterm = any(aa in "KR" for aa in nterm[:5])
    if hydrophobic_core >= 0.58 and has_basic_nterm:
        return [
            {
                "feature_type": "signal_peptide",
                "name": "Signal peptide-like N-terminus",
                "start": 1,
                "end": 30,
                "score": hydrophobic_core,
            }
        ]
    return []


def _coiled_coils(seq: str) -> list[dict]:
    features = []
    window = 28
    for start in range(0, max(len(seq) - window + 1, 0), 7):
        fragment = seq[start : start + window]
        heptad_positions = fragment[0::7] + fragment[3::7]
        ratio = sum(aa in HYDROPHOBIC for aa in heptad_positions) / max(len(heptad_positions), 1)
        charged = sum(aa in "EKR" for aa in fragment) / window
        if ratio >= 0.5 and charged >= 0.2:
            features.append(
                {
                    "feature_type": "coiled_coil",
                    "name": "Coiled-coil-like heptad repeat",
                    "start": start + 1,
                    "end": start + window,
                    "score": round((ratio + charged) / 2, 3),
                }
            )
    return _merge_overlaps(features)


def _disorder(seq: str) -> list[dict]:
    features = []
    window = 30
    for start in range(0, max(len(seq) - window + 1, 0), 10):
        fragment = seq[start : start + window]
        ratio = sum(aa in DISORDER_PROMOTING for aa in fragment) / window
        hydrophobic = sum(aa in HYDROPHOBIC for aa in fragment) / window
        score = ratio - hydrophobic
        if score >= 0.28:
            features.append(
                {
                    "feature_type": "disorder",
                    "name": "Intrinsically disordered-like region",
                    "start": start + 1,
                    "end": start + window,
                    "score": round(score, 3),
                }
            )
    return _merge_overlaps(features)


def _cellular_location(seq: str, features: list[dict]) -> str:
    types = {feature["feature_type"] for feature in features}
    if "signal_peptide" in types:
        return "secretory_pathway_or_membrane_candidate"
    if "transmembrane" in types:
        return "membrane_candidate"
    basic_fraction = sum(aa in "KR" for aa in seq[:60]) / max(min(len(seq), 60), 1)
    if basic_fraction > 0.18:
        return "nuclear_candidate"
    return "unknown"


def _merge_overlaps(features: list[dict]) -> list[dict]:
    if not features:
        return []
    features = sorted(features, key=lambda item: (item["feature_type"], item["start"], item["end"]))
    merged: list[dict] = []
    for feature in features:
        if (
            merged
            and feature["feature_type"] == merged[-1]["feature_type"]
            and feature["start"] <= merged[-1]["end"] + 1
        ):
            merged[-1]["end"] = max(merged[-1]["end"], feature["end"])
            merged[-1]["score"] = max(merged[-1].get("score") or 0, feature.get("score") or 0)
        else:
            merged.append(dict(feature))
    return merged

