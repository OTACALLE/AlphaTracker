from __future__ import annotations

from urllib.parse import quote

from alphatracker.config import get_settings
from alphatracker.http import HttpClient
from alphatracker.schemas import EvidenceResult


class RepositoryEvidenceClient:
    def __init__(self):
        settings = get_settings()
        github_headers = {}
        if settings.github_token:
            github_headers["Authorization"] = f"Bearer {settings.github_token}"
        self.default_client = HttpClient()
        self.github_client = HttpClient(headers=github_headers)

    async def search_all(self, protein_name: str, accession: str | None = None) -> list[EvidenceResult]:
        queries = [protein_name]
        if accession:
            queries.append(accession)
        results: list[EvidenceResult] = []
        for query in queries:
            results.extend(
                [
                    await self.search_zenodo(query),
                    await self.search_figshare(query),
                    await self.search_github(query),
                    self.placeholder("dryad", query),
                    self.placeholder("osf", query),
                ]
            )
        return results

    async def search_zenodo(self, query: str) -> EvidenceResult:
        try:
            payload = await self.default_client.get_json(
                "https://zenodo.org/api/records",
                params={"q": f'{query} AND (pdb OR cif OR mmcif OR AlphaFold OR ColabFold)', "size": 5},
            )
        except Exception as exc:
            return EvidenceResult(source="zenodo", status="inconclusive", message=str(exc))
        hits = payload.get("hits", {}).get("hits", [])
        if hits:
            first = hits[0]
            return EvidenceResult(
                source="zenodo",
                status="found",
                identifier=str(first.get("id")),
                url=first.get("links", {}).get("self_html"),
                confidence=0.6,
                message="Potential structural-model repository evidence found in Zenodo.",
                raw_response={"count": len(hits), "first": first},
            )
        return EvidenceResult(source="zenodo", status="not_found", confidence=0.5, message="No Zenodo hit found.")

    async def search_figshare(self, query: str) -> EvidenceResult:
        try:
            payload = await self.default_client.post_json(
                "https://api.figshare.com/v2/articles/search",
                {"search_for": f"{query} pdb cif AlphaFold ColabFold", "page_size": 5},
            )
        except Exception as exc:
            return EvidenceResult(source="figshare", status="inconclusive", message=str(exc))
        if isinstance(payload, list) and payload:
            first = payload[0]
            return EvidenceResult(
                source="figshare",
                status="found",
                identifier=str(first.get("id")),
                url=first.get("url_public_html"),
                confidence=0.6,
                message="Potential structural-model repository evidence found in Figshare.",
                raw_response={"count": len(payload), "first": first},
            )
        return EvidenceResult(source="figshare", status="not_found", confidence=0.5, message="No Figshare hit found.")

    async def search_github(self, query: str) -> EvidenceResult:
        encoded = quote(f'"{query}" alphafold OR colabfold OR pdb OR cif')
        try:
            payload = await self.github_client.get_json(
                f"https://api.github.com/search/repositories?q={encoded}&per_page=5"
            )
        except Exception as exc:
            return EvidenceResult(source="github", status="inconclusive", message=str(exc))
        total = payload.get("total_count", 0)
        if total:
            first = payload.get("items", [{}])[0]
            return EvidenceResult(
                source="github",
                status="found",
                identifier=first.get("full_name"),
                url=first.get("html_url"),
                confidence=0.4,
                message="Potential public GitHub structural evidence found.",
                raw_response={"total_count": total, "first": first},
            )
        return EvidenceResult(source="github", status="not_found", confidence=0.4, message="No GitHub hit found.")

    def placeholder(self, source: str, query: str) -> EvidenceResult:
        return EvidenceResult(
            source=source,
            status="skipped",
            confidence=0.0,
            message=f"{source} connector interface is configured but not enabled in this first implementation.",
            raw_response={"query": query},
        )

