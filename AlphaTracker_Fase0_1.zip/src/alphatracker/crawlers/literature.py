from __future__ import annotations

from datetime import date, datetime, timedelta, timezone
from urllib.parse import quote

from dateutil.parser import parse as parse_date

from alphatracker.config import get_settings, get_source_config
from alphatracker.http import HttpClient
from alphatracker.logging import get_logger
from alphatracker.schemas import PublicationIn

logger = get_logger(__name__)


def _date_range(lookback_days: int) -> tuple[date, date]:
    end = datetime.now(timezone.utc).date()
    start = end - timedelta(days=lookback_days)
    return start, end


class BioRxivCrawler:
    base_url = "https://api.biorxiv.org"

    def __init__(self, server: str):
        self.server = server
        self.client = HttpClient()

    async def fetch_recent(self, lookback_days: int | None = None) -> list[PublicationIn]:
        settings = get_settings()
        start, end = _date_range(lookback_days or settings.lookback_days)
        cursor = 0
        publications: list[PublicationIn] = []

        while True:
            url = f"{self.base_url}/details/{self.server}/{start.isoformat()}/{end.isoformat()}/{cursor}"
            payload = await self.client.get_json(url)
            collection = payload.get("collection", [])
            for item in collection:
                publications.append(self._map_item(item))
            messages = payload.get("messages", [{}])
            total = int(messages[0].get("total", len(publications)) or len(publications))
            cursor += len(collection)
            if not collection or cursor >= total:
                break
        return publications

    def _map_item(self, item: dict) -> PublicationIn:
        doi = item.get("doi")
        return PublicationIn(
            source=self.server,
            source_id=doi,
            doi=doi,
            title=item.get("title") or "Untitled preprint",
            abstract=item.get("abstract"),
            journal=self.server,
            published_date=parse_date(item["date"]) if item.get("date") else None,
            url=f"https://www.{self.server}.org/content/{doi}" if doi else None,
            authors=[name.strip() for name in (item.get("authors") or "").split(";") if name.strip()],
            raw_metadata=item,
        )


class ArxivCrawler:
    base_url = "https://export.arxiv.org/api/query"

    def __init__(self):
        self.client = HttpClient()

    async def fetch_recent(self, lookback_days: int | None = None) -> list[PublicationIn]:
        settings = get_settings()
        source_config = get_source_config()
        categories = source_config.get("polling", {}).get("categories", {}).get("arxiv", ["q-bio"])
        start, _ = _date_range(lookback_days or settings.lookback_days)
        query = " OR ".join([f"cat:{category}" for category in categories])
        params = {
            "search_query": query,
            "sortBy": "submittedDate",
            "sortOrder": "descending",
            "start": 0,
            "max_results": 50,
        }
        text = await self.client.get_text(self.base_url, params=params)
        return self._parse_atom(text, start)

    def _parse_atom(self, text: str, since: date) -> list[PublicationIn]:
        import xml.etree.ElementTree as ET

        ns = {"atom": "http://www.w3.org/2005/Atom", "arxiv": "http://arxiv.org/schemas/atom"}
        root = ET.fromstring(text)
        publications: list[PublicationIn] = []
        for entry in root.findall("atom:entry", ns):
            published_raw = entry.findtext("atom:published", default="", namespaces=ns)
            published_dt = parse_date(published_raw) if published_raw else None
            if published_dt and published_dt.date() < since:
                continue
            arxiv_id = (entry.findtext("atom:id", default="", namespaces=ns) or "").rsplit("/", 1)[-1]
            doi = entry.findtext("arxiv:doi", default=None, namespaces=ns)
            title = " ".join((entry.findtext("atom:title", default="Untitled", namespaces=ns) or "").split())
            abstract = " ".join((entry.findtext("atom:summary", default="", namespaces=ns) or "").split())
            authors = [
                author.findtext("atom:name", default="", namespaces=ns)
                for author in entry.findall("atom:author", ns)
            ]
            publications.append(
                PublicationIn(
                    source="arxiv",
                    source_id=arxiv_id,
                    doi=doi,
                    title=title,
                    abstract=abstract,
                    journal="arXiv",
                    published_date=published_dt,
                    url=f"https://arxiv.org/abs/{quote(arxiv_id)}" if arxiv_id else None,
                    authors=[author for author in authors if author],
                    raw_metadata={"arxiv_id": arxiv_id},
                )
            )
        return publications


class PubMedCrawler:
    base_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"

    def __init__(self):
        self.client = HttpClient()

    async def fetch_recent(self, lookback_days: int | None = None) -> list[PublicationIn]:
        settings = get_settings()
        start, end = _date_range(lookback_days or settings.lookback_days)
        terms = get_source_config().get("queries", {}).get("protein_discovery_terms", [])
        term = "(" + " OR ".join([f'"{item}"' for item in terms]) + ") AND protein"
        params = {
            "db": "pubmed",
            "term": term,
            "retmode": "json",
            "retmax": 100,
            "mindate": start.isoformat(),
            "maxdate": end.isoformat(),
            "datetype": "pdat",
        }
        if settings.ncbi_email:
            params["email"] = settings.ncbi_email
        if settings.ncbi_api_key:
            params["api_key"] = settings.ncbi_api_key
        search = await self.client.get_json(f"{self.base_url}/esearch.fcgi", params=params)
        ids = search.get("esearchresult", {}).get("idlist", [])
        if not ids:
            return []
        summary_params = {
            "db": "pubmed",
            "id": ",".join(ids),
            "retmode": "json",
        }
        if settings.ncbi_email:
            summary_params["email"] = settings.ncbi_email
        if settings.ncbi_api_key:
            summary_params["api_key"] = settings.ncbi_api_key
        summary = await self.client.get_json(f"{self.base_url}/esummary.fcgi", params=summary_params)
        result = summary.get("result", {})
        publications: list[PublicationIn] = []
        for pmid in result.get("uids", []):
            item = result.get(pmid, {})
            publications.append(self._map_summary(pmid, item))
        return publications

    def _map_summary(self, pmid: str, item: dict) -> PublicationIn:
        authors = [author.get("name") for author in item.get("authors", []) if author.get("name")]
        published = None
        if item.get("pubdate"):
            try:
                published = parse_date(item["pubdate"], default=datetime(1900, 1, 1))
            except Exception:
                published = None
        doi = None
        for article_id in item.get("articleids", []):
            if article_id.get("idtype") == "doi":
                doi = article_id.get("value")
        return PublicationIn(
            source="pubmed",
            source_id=pmid,
            doi=doi,
            title=item.get("title") or "Untitled PubMed record",
            abstract=None,
            journal=item.get("fulljournalname") or item.get("source"),
            published_date=published,
            url=f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/",
            authors=authors,
            raw_metadata=item,
        )


async def fetch_all_recent_publications(lookback_days: int | None = None) -> list[PublicationIn]:
    crawlers = [
        BioRxivCrawler("biorxiv"),
        BioRxivCrawler("medrxiv"),
        ArxivCrawler(),
        PubMedCrawler(),
    ]
    publications: list[PublicationIn] = []
    for crawler in crawlers:
        try:
            publications.extend(await crawler.fetch_recent(lookback_days=lookback_days))
        except Exception as exc:
            logger.warning("crawler_failed", crawler=crawler.__class__.__name__, error=str(exc))
    return publications

