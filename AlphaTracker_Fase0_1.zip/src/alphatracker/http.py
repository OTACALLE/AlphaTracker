from __future__ import annotations

from typing import Any

import httpx
from tenacity import retry, stop_after_attempt, wait_exponential

from alphatracker.config import get_settings
from alphatracker.logging import get_logger

logger = get_logger(__name__)


class HttpClient:
    def __init__(self, base_url: str | None = None, headers: dict[str, str] | None = None):
        settings = get_settings()
        self.base_url = base_url
        self.timeout = settings.http_timeout_seconds
        self.headers = headers or {}

    @retry(wait=wait_exponential(multiplier=1, min=1, max=12), stop=stop_after_attempt(3))
    async def get_json(self, url: str, params: dict[str, Any] | None = None) -> Any:
        target = url if url.startswith("http") else f"{self.base_url}{url}"
        async with httpx.AsyncClient(timeout=self.timeout, headers=self.headers) as client:
            response = await client.get(target, params=params)
            response.raise_for_status()
            return response.json()

    @retry(wait=wait_exponential(multiplier=1, min=1, max=12), stop=stop_after_attempt(3))
    async def get_text(self, url: str, params: dict[str, Any] | None = None) -> str:
        target = url if url.startswith("http") else f"{self.base_url}{url}"
        async with httpx.AsyncClient(timeout=self.timeout, headers=self.headers) as client:
            response = await client.get(target, params=params)
            response.raise_for_status()
            return response.text

    @retry(wait=wait_exponential(multiplier=1, min=1, max=12), stop=stop_after_attempt(3))
    async def post_json(self, url: str, payload: dict[str, Any]) -> Any:
        target = url if url.startswith("http") else f"{self.base_url}{url}"
        async with httpx.AsyncClient(timeout=self.timeout, headers=self.headers) as client:
            response = await client.post(target, json=payload)
            response.raise_for_status()
            return response.json()

