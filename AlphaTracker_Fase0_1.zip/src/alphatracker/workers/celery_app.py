from __future__ import annotations

from celery import Celery

from alphatracker.config import get_settings
from alphatracker.db.session import SessionLocal, create_all
from alphatracker.pipeline.runner import run_once_sync

settings = get_settings()

celery_app = Celery(
    "alphatracker",
    broker=settings.redis_url,
    backend=settings.redis_url,
)

celery_app.conf.timezone = "UTC"
celery_app.conf.beat_schedule = {
    "alpha-tracker-monitor": {
        "task": "alphatracker.monitor",
        "schedule": settings.poll_interval_minutes * 60,
    }
}


@celery_app.task(name="alphatracker.monitor")
def monitor() -> dict[str, int]:
    create_all()
    session = SessionLocal()
    try:
        return run_once_sync(session)
    finally:
        session.close()

