from __future__ import annotations

import enum
from datetime import datetime, timezone

from sqlalchemy import (
    JSON,
    Boolean,
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from alphatracker.db.session import Base


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class EvidenceStatus(str, enum.Enum):
    found = "found"
    not_found = "not_found"
    inconclusive = "inconclusive"
    skipped = "skipped"


class AlertStatus(str, enum.Enum):
    open = "open"
    acknowledged = "acknowledged"
    dismissed = "dismissed"


class Publication(Base):
    __tablename__ = "publications"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    source: Mapped[str] = mapped_column(String(80), index=True)
    source_id: Mapped[str | None] = mapped_column(String(255), index=True)
    doi: Mapped[str | None] = mapped_column(String(255), index=True)
    title: Mapped[str] = mapped_column(Text)
    abstract: Mapped[str | None] = mapped_column(Text)
    journal: Mapped[str | None] = mapped_column(String(255))
    published_date: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    url: Mapped[str | None] = mapped_column(Text)
    raw_metadata: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)

    proteins: Mapped[list["Protein"]] = relationship(back_populates="publication")
    authors: Mapped[list["Author"]] = relationship(back_populates="publication", cascade="all, delete-orphan")

    __table_args__ = (
        UniqueConstraint("source", "source_id", name="uq_publication_source_id"),
        Index("ix_publication_doi_source", "doi", "source"),
    )


class Author(Base):
    __tablename__ = "authors"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    publication_id: Mapped[int] = mapped_column(ForeignKey("publications.id"), index=True)
    name: Mapped[str] = mapped_column(String(255))
    ordinal: Mapped[int] = mapped_column(Integer, default=0)
    publication: Mapped[Publication] = relationship(back_populates="authors")


class Organism(Base):
    __tablename__ = "organisms"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    scientific_name: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    taxonomy_id: Mapped[str | None] = mapped_column(String(80), index=True)
    is_human: Mapped[bool] = mapped_column(Boolean, default=False)
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict)

    proteins: Mapped[list["Protein"]] = relationship(back_populates="organism")


class Protein(Base):
    __tablename__ = "proteins"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(500), index=True)
    # Normalized (whitespace-collapsed, case-folded) copy of `name`, used as a
    # fallback deduplication key for candidates that have no recoverable sequence
    # (and therefore no `sequence_hash`) -- see ALPHATRACKER_RELATORIO_TECNICO.md
    # §4.1. Not a uniqueness constraint at the DB level; lookups are done in
    # pipeline.runner alongside `publication_id`, mirroring how `sequence_hash`
    # dedup is already handled (app-level lookup-before-insert, not a DB constraint).
    name_normalized: Mapped[str | None] = mapped_column(String(500), index=True)
    publication_id: Mapped[int | None] = mapped_column(ForeignKey("publications.id"), index=True)
    organism_id: Mapped[int | None] = mapped_column(ForeignKey("organisms.id"), index=True)
    accession: Mapped[str | None] = mapped_column(String(120), index=True)
    sequence_hash: Mapped[str | None] = mapped_column(String(64), index=True)
    length: Mapped[int | None] = mapped_column(Integer)
    is_complete: Mapped[bool] = mapped_column(Boolean, default=False)
    completeness_reason: Mapped[str | None] = mapped_column(Text)
    score: Mapped[float] = mapped_column(Float, default=0.0, index=True)
    score_components: Mapped[dict] = mapped_column(JSON, default=dict)
    summary: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)

    publication: Mapped[Publication | None] = relationship(back_populates="proteins")
    organism: Mapped[Organism | None] = relationship(back_populates="proteins")
    sequences: Mapped[list["Sequence"]] = relationship(back_populates="protein", cascade="all, delete-orphan")
    features: Mapped[list["SequenceFeature"]] = relationship(back_populates="protein", cascade="all, delete-orphan")
    structure_evidence: Mapped[list["StructureEvidence"]] = relationship(
        back_populates="protein", cascade="all, delete-orphan"
    )
    literature_evidence: Mapped[list["LiteratureEvidence"]] = relationship(
        back_populates="protein", cascade="all, delete-orphan"
    )
    repository_evidence: Mapped[list["RepositoryEvidence"]] = relationship(
        back_populates="protein", cascade="all, delete-orphan"
    )
    alerts: Mapped[list["Alert"]] = relationship(back_populates="protein", cascade="all, delete-orphan")

    __table_args__ = (
        Index("ix_protein_publication_name_normalized", "publication_id", "name_normalized"),
    )


class Sequence(Base):
    __tablename__ = "sequences"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    protein_id: Mapped[int] = mapped_column(ForeignKey("proteins.id"), index=True)
    fasta_header: Mapped[str | None] = mapped_column(Text)
    sequence: Mapped[str] = mapped_column(Text)
    sequence_hash: Mapped[str] = mapped_column(String(64), index=True)
    length: Mapped[int] = mapped_column(Integer)
    source: Mapped[str] = mapped_column(String(80))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    protein: Mapped[Protein] = relationship(back_populates="sequences")


class SequenceFeature(Base):
    __tablename__ = "sequence_features"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    protein_id: Mapped[int] = mapped_column(ForeignKey("proteins.id"), index=True)
    feature_type: Mapped[str] = mapped_column(String(120), index=True)
    name: Mapped[str] = mapped_column(String(255))
    start: Mapped[int | None] = mapped_column(Integer)
    end: Mapped[int | None] = mapped_column(Integer)
    score: Mapped[float | None] = mapped_column(Float)
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict)

    protein: Mapped[Protein] = relationship(back_populates="features")


class ExternalReference(Base):
    __tablename__ = "external_references"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    protein_id: Mapped[int | None] = mapped_column(ForeignKey("proteins.id"), index=True)
    database: Mapped[str] = mapped_column(String(120), index=True)
    identifier: Mapped[str] = mapped_column(String(255), index=True)
    url: Mapped[str | None] = mapped_column(Text)
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict)


class StructureEvidence(Base):
    __tablename__ = "structure_evidence"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    protein_id: Mapped[int] = mapped_column(ForeignKey("proteins.id"), index=True)
    source: Mapped[str] = mapped_column(String(120), index=True)
    status: Mapped[EvidenceStatus] = mapped_column(Enum(EvidenceStatus), default=EvidenceStatus.inconclusive)
    method: Mapped[str | None] = mapped_column(String(120))
    identifier: Mapped[str | None] = mapped_column(String(255))
    url: Mapped[str | None] = mapped_column(Text)
    confidence: Mapped[float] = mapped_column(Float, default=0.0)
    message: Mapped[str | None] = mapped_column(Text)
    checked_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    raw_response: Mapped[dict] = mapped_column(JSON, default=dict)

    protein: Mapped[Protein] = relationship(back_populates="structure_evidence")


class LiteratureEvidence(Base):
    __tablename__ = "literature_evidence"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    protein_id: Mapped[int] = mapped_column(ForeignKey("proteins.id"), index=True)
    query: Mapped[str] = mapped_column(Text)
    source: Mapped[str] = mapped_column(String(120), index=True)
    status: Mapped[EvidenceStatus] = mapped_column(Enum(EvidenceStatus), default=EvidenceStatus.inconclusive)
    title: Mapped[str | None] = mapped_column(Text)
    doi: Mapped[str | None] = mapped_column(String(255))
    url: Mapped[str | None] = mapped_column(Text)
    checked_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    raw_response: Mapped[dict] = mapped_column(JSON, default=dict)

    protein: Mapped[Protein] = relationship(back_populates="literature_evidence")


class RepositoryEvidence(Base):
    __tablename__ = "repository_evidence"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    protein_id: Mapped[int] = mapped_column(ForeignKey("proteins.id"), index=True)
    source: Mapped[str] = mapped_column(String(120), index=True)
    query: Mapped[str] = mapped_column(Text)
    status: Mapped[EvidenceStatus] = mapped_column(Enum(EvidenceStatus), default=EvidenceStatus.inconclusive)
    identifier: Mapped[str | None] = mapped_column(String(255))
    url: Mapped[str | None] = mapped_column(Text)
    checked_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    raw_response: Mapped[dict] = mapped_column(JSON, default=dict)

    protein: Mapped[Protein] = relationship(back_populates="repository_evidence")


class PipelineRun(Base):
    __tablename__ = "pipeline_runs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    source: Mapped[str] = mapped_column(String(120), index=True)
    status: Mapped[str] = mapped_column(String(80), index=True)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    counters: Mapped[dict] = mapped_column(JSON, default=dict)
    error: Mapped[str | None] = mapped_column(Text)


class QueryHistory(Base):
    __tablename__ = "query_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    source: Mapped[str] = mapped_column(String(120), index=True)
    query: Mapped[str] = mapped_column(Text)
    status_code: Mapped[int | None] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(80))
    cached: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict)


class Alert(Base):
    __tablename__ = "alerts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    protein_id: Mapped[int] = mapped_column(ForeignKey("proteins.id"), index=True)
    status: Mapped[AlertStatus] = mapped_column(Enum(AlertStatus), default=AlertStatus.open)
    score: Mapped[float] = mapped_column(Float, index=True)
    reason: Mapped[str] = mapped_column(Text)
    justification: Mapped[str] = mapped_column(Text)
    evidence_statement: Mapped[str] = mapped_column(Text)
    bases_consulted: Mapped[list] = mapped_column(JSON, default=list)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    protein: Mapped[Protein] = relationship(back_populates="alerts")


class AuditLog(Base):
    __tablename__ = "audit_log"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    entity_type: Mapped[str] = mapped_column(String(120), index=True)
    entity_id: Mapped[str] = mapped_column(String(120), index=True)
    action: Mapped[str] = mapped_column(String(120), index=True)
    message: Mapped[str | None] = mapped_column(Text)
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class SystemLog(Base):
    __tablename__ = "system_logs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    level: Mapped[str] = mapped_column(String(40), index=True)
    logger: Mapped[str] = mapped_column(String(120), index=True)
    message: Mapped[str] = mapped_column(Text)
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
