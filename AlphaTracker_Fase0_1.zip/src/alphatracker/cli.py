from __future__ import annotations

import typer

from alphatracker.db.session import SessionLocal, create_all
from alphatracker.pipeline.runner import run_once_sync

app = typer.Typer(help="Alpha Tracker operational commands.")


@app.command("init-db")
def init_db() -> None:
    create_all()
    typer.echo("Database schema initialized.")


@app.command("run-once")
def run_once(lookback_days: int | None = typer.Option(None, min=1, max=90)) -> None:
    create_all()
    session = SessionLocal()
    try:
        counters = run_once_sync(session, lookback_days=lookback_days)
    finally:
        session.close()
    typer.echo(counters)

