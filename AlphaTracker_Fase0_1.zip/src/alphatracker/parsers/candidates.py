from __future__ import annotations

import re

from alphatracker.schemas import CandidateProtein, PublicationIn
from alphatracker.utils.sequences import extract_accessions, parse_fasta_blocks

PROTEIN_NAME_PATTERNS = [
    re.compile(r"(?P<name>[A-Z][A-Za-z0-9\- ]{2,80} protein)\b"),
    re.compile(r"protein (?P<name>[A-Z0-9][A-Za-z0-9\-]{1,40})\b"),
    re.compile(r"(?P<name>[A-Z0-9]{2,12})\s+(?:is|was|as)\s+(?:a\s+)?(?:novel|new)", re.I),
]

ORGANISM_PATTERNS = [
    re.compile(r"\b(?:in|from)\s+(?P<organism>Homo sapiens|human|Mus musculus|mouse|Rattus norvegicus|rat)\b", re.I),
    re.compile(r"\borganism[:\s]+(?P<organism>[A-Z][a-z]+ [a-z][a-z\-]+)\b"),
]


def extract_candidates(publication: PublicationIn) -> list[CandidateProtein]:
    text = "\n".join(filter(None, [publication.title, publication.abstract or ""]))
    fasta_blocks = parse_fasta_blocks(text)
    accessions = extract_accessions(text)
    names = _extract_names(text)
    organism = _extract_organism(text)

    candidates: list[CandidateProtein] = []
    if fasta_blocks:
        for header, sequence in fasta_blocks:
            candidates.append(
                CandidateProtein(
                    name=_name_from_header(header) or (names[0] if names else "Uncharacterized protein"),
                    organism=organism,
                    accession=accessions[0] if accessions else None,
                    fasta_header=header,
                    sequence=sequence,
                    publication=publication,
                    evidence_hints={"names": names, "accessions": accessions},
                )
            )
    elif accessions or names:
        for name in names or ["Uncharacterized protein"]:
            candidates.append(
                CandidateProtein(
                    name=name,
                    organism=organism,
                    accession=accessions[0] if accessions else None,
                    publication=publication,
                    evidence_hints={"names": names, "accessions": accessions},
                )
            )
    return candidates


def _extract_names(text: str) -> list[str]:
    names: list[str] = []
    for pattern in PROTEIN_NAME_PATTERNS:
        for match in pattern.finditer(text):
            name = " ".join(match.group("name").split())
            if 2 <= len(name) <= 120:
                names.append(name)
    deduped = []
    seen = set()
    for name in names:
        lower = name.lower()
        if lower not in seen:
            seen.add(lower)
            deduped.append(name)
    return deduped[:5]


def _extract_organism(text: str) -> str | None:
    for pattern in ORGANISM_PATTERNS:
        match = pattern.search(text)
        if match:
            organism = match.group("organism")
            if organism.lower() == "human":
                return "Homo sapiens"
            if organism.lower() == "mouse":
                return "Mus musculus"
            if organism.lower() == "rat":
                return "Rattus norvegicus"
            return organism
    return None


def _name_from_header(header: str) -> str | None:
    tokens = header.split()
    if not tokens:
        return None
    if len(tokens) >= 2:
        return " ".join(tokens[1:8])
    return tokens[0]

