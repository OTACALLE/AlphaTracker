from alphatracker.utils.sequences import check_complete_protein, parse_fasta_blocks, sequence_hash


def test_parse_fasta_blocks_extracts_sequence():
    text = ">P1 example protein\nMKTAYIAKQRQISFVKSHFSRQ\n"
    blocks = parse_fasta_blocks(text)
    assert blocks == [("P1 example protein", "MKTAYIAKQRQISFVKSHFSRQ")]


def test_complete_sequence_passes_basic_checks():
    result = check_complete_protein("MKTAYIAKQRQISFVKSHFSRQ")
    assert result.is_complete is True
    assert result.normalized_sequence == "MKTAYIAKQRQISFVKSHFSRQ"


def test_internal_stop_rejects_sequence():
    result = check_complete_protein("MKTAYIAKQ*RQISFVKSHFSRQ")
    assert result.is_complete is False
    assert "internal stop" in result.reason


def test_sequence_hash_is_stable_after_normalization():
    assert sequence_hash("MKT A") == sequence_hash("mkta")

