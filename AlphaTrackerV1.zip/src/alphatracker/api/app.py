from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from alphatracker.api.routes import router
from alphatracker.db.session import create_all
from alphatracker.logging import configure_logging


def create_app() -> FastAPI:
    configure_logging()
    app = FastAPI(
        title="Alpha Tracker API",
        version="0.1.0",
        description=(
            "Scientific monitoring API for complete protein sequences without public structural evidence "
            "in queried sources."
        ),
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.on_event("startup")
    def startup() -> None:
        create_all()

    app.include_router(router)
    return app

