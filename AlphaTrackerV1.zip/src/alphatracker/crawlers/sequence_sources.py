from __future__ import annotations

from alphatracker.config import get_settings
from alphatracker.http import HttpClient
from alphatracker.schemas import EvidenceResult
from alphatracker.utils.sequences import normalize_sequence


class UniProtClient:
    base_url = "https://rest.uniprot.org"

    def __init__(self):
        self.client = HttpClient()

    async def fetch_by_accession(self, accession: str) -> dict | None:
        try:
            return await self.client.get_json(f"{self.base_url}/uniprotkb/{accession}.json")
        except Exception:
            return None

    async def search_by_sequence(self, sequence: str) -> list[dict]:
        normalized = normalize_sequence(sequence)
        if not normalized:
            return []
        query = f"(sequence:{normalized})"
        try:
            payload = await self.client.get_json(
                f"{self.base_url}/uniprotkb/search",
                params={"query": query, "format": "json", "size": 5},
            )
        except Exception:
            return []
        return payload.get("results", [])


class NCBIProteinClient:
    base_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"

    def __init__(self):
        self.client = HttpClient()

    async def fetch_fasta(self, accession: str) -> tuple[str | None, str | None]:
        settings = get_settings()
        params = {
            "db": "protein",
            "id": accession,
            "rettype": "fasta",
            "retmode": "text",
        }
        if settings.ncbi_email:
            params["email"] = settings.ncbi_email
        if settings.ncbi_api_key:
            params["api_key"] = settings.ncbi_api_key
        try:
            text = await self.client.get_text(f"{self.base_url}/efetch.fcgi", params=params)
        except Exception:
            return None, None
        if not text.startswith(">"):
            return None, None
        header, *body = text.splitlines()
        return header[1:], normalize_sequence("".join(body))


class AlphaFoldClient:
    base_url = "https://alphafold.ebi.ac.uk/api"

    def __init__(self):
        self.client = HttpClient()

    async def check_accession(self, accession: str | None) -> EvidenceResult:
        if not accession:
            return EvidenceResult(
                source="alphafold_db",
                status="skipped",
                message="No accession available for AlphaFold DB lookup.",
            )
        try:
            payload = await self.client.get_json(f"{self.base_url}/prediction/{accession}")
        except Exception as exc:
            return EvidenceResult(
                source="alphafold_db",
                status="inconclusive",
                message=f"AlphaFold DB lookup failed: {exc}",
            )
        if isinstance(payload, list) and payload:
            first = payload[0]
            return EvidenceResult(
                source="alphafold_db",
                status="found",
                identifier=accession,
                url=first.get("cifUrl") or first.get("pdbUrl"),
                confidence=1.0,
                message="Public AlphaFold DB prediction was found for this accession.",
                raw_response={"count": len(payload), "first": first},
            )
        return EvidenceResult(
            source="alphafold_db",
            status="not_found",
            identifier=accession,
            confidence=0.8,
            message="No public AlphaFold DB prediction was found for this accession.",
            raw_response={"count": 0},
        )


class RCSBClient:
    search_url = "https://search.rcsb.org/rcsbsearch/v2/query"
    data_url = "https://data.rcsb.org/rest/v1/core/entry"

    def __init__(self):
        self.client = HttpClient()

    async def check_accession(self, accession: str | None) -> EvidenceResult:
        if not accession:
            return EvidenceResult(
                source="pdb",
                status="skipped",
                message="No accession available for PDB lookup.",
            )
        query = {
            "query": {
                "type": "terminal",
                "service": "text",
                "parameters": {
                    "attribute": "rcsb_polymer_entity_container_identifiers.reference_sequence_identifiers.database_accession",
                    "operator": "exact_match",
                    "value": accession,
                },
            },
            "return_type": "entry",
            "request_options": {"paginate": {"start": 0, "rows": 10}},
        }
        try:
            payload = await self.client.post_json(self.search_url, query)
        except Exception as exc:
            return EvidenceResult(source="pdb", status="inconclusive", message=f"PDB lookup failed: {exc}")
        hits = payload.get("result_set", [])
        if not hits:
            return EvidenceResult(
                source="pdb",
                status="not_found",
                identifier=accession,
                confidence=0.8,
                message="No PDB entry was found through accession search.",
                raw_response={"count": 0},
            )
        pdb_id = hits[0]["identifier"]
        method = None
        try:
            entry = await self.client.get_json(f"{self.data_url}/{pdb_id}")
            methods = entry.get("exptl", [])
            if methods:
                method = methods[0].get("method")
        except Exception:
            entry = {}
        return EvidenceResult(
            source="pdb",
            status="found",
            method=method,
            identifier=pdb_id,
            url=f"https://www.rcsb.org/structure/{pdb_id}",
            confidence=1.0,
            message="Experimental public PDB structure was found.",
            raw_response={"count": len(hits), "entry": entry},
        )

