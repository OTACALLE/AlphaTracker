from __future__ import annotations

import asyncio
from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from alphatracker.analysis.sequence import analyze_sequence
from alphatracker.config import get_settings
from alphatracker.crawlers.literature import fetch_all_recent_publications
from alphatracker.crawlers.repositories import RepositoryEvidenceClient
from alphatracker.crawlers.sequence_sources import AlphaFoldClient, NCBIProteinClient, RCSBClient
from alphatracker.db.models import (
    Alert,
    Author,
    EvidenceStatus,
    LiteratureEvidence,
    Organism,
    PipelineRun,
    Protein,
    Publication,
    RepositoryEvidence,
    Sequence,
    SequenceFeature,
    StructureEvidence,
)
from alphatracker.logging import get_logger
from alphatracker.parsers.candidates import extract_candidates
from alphatracker.pipeline.alerts import EVIDENCE_STATEMENT, alert_reason
from alphatracker.pipeline.scoring import score_protein
from alphatracker.schemas import CandidateProtein, EvidenceResult, PublicationIn
from alphatracker.utils.sequences import check_complete_protein, sequence_hash

logger = get_logger(__name__)


class PipelineRunner:
    def __init__(self, session: Session):
        self.session = session
        self.ncbi = NCBIProteinClient()
        self.alphafold = AlphaFoldClient()
        self.rcsb = RCSBClient()
        self.repositories = RepositoryEvidenceClient()

    async def run_once(self, lookback_days: int | None = None) -> dict[str, int]:
        run = PipelineRun(source="all", status="running", counters={})
        self.session.add(run)
        self.session.commit()
        counters = {
            "publications": 0,
            "candidates": 0,
            "complete": 0,
            "proteins_saved": 0,
            "alerts": 0,
            "errors": 0,
        }
        try:
            publications = await fetch_all_recent_publications(lookback_days=lookback_days)
            counters["publications"] = len(publications)
            for publication in publications:
                try:
                    candidates = extract_candidates(publication)
                    counters["candidates"] += len(candidates)
                    for candidate in candidates:
                        saved = await self.process_candidate(candidate)
                        if saved:
                            counters["proteins_saved"] += 1
                            if saved.is_complete:
                                counters["complete"] += 1
                            counters["alerts"] += len(saved.alerts)
                except Exception as exc:
                    counters["errors"] += 1
                    logger.warning("publication_processing_failed", title=publication.title, error=str(exc))
            run.status = "completed"
        except Exception as exc:
            run.status = "failed"
            run.error = str(exc)
            counters["errors"] += 1
            logger.exception("pipeline_failed", error=str(exc))
        finally:
            run.finished_at = datetime.now(timezone.utc)
            run.counters = counters
            self.session.add(run)
            self.session.commit()
        return counters

    async def process_candidate(self, candidate: CandidateProtein) -> Protein | None:
        publication = self._upsert_publication(candidate.publication)
        sequence = candidate.sequence
        fasta_header = candidate.fasta_header
        if not sequence and candidate.accession:
            fasta_header, sequence = await self.ncbi.fetch_fasta(candidate.accession)

        completeness = check_complete_protein(sequence)
        organism = self._upsert_organism(candidate.organism)
        seq_hash = sequence_hash(completeness.normalized_sequence) if completeness.normalized_sequence else None

        existing = None
        if seq_hash:
            existing = self.session.scalar(select(Protein).where(Protein.sequence_hash == seq_hash))
        protein = existing or Protein(
            name=candidate.name,
            publication=publication,
            organism=organism,
            accession=candidate.accession,
        )
        protein.name = candidate.name
        protein.publication = publication
        protein.organism = organism
        protein.accession = candidate.accession
        protein.sequence_hash = seq_hash
        protein.length = len(completeness.normalized_sequence) if completeness.normalized_sequence else None
        protein.is_complete = completeness.is_complete
        protein.completeness_reason = completeness.reason
        self.session.add(protein)
        self.session.flush()

        if completeness.normalized_sequence and not existing:
            self.session.add(
                Sequence(
                    protein=protein,
                    fasta_header=fasta_header,
                    sequence=completeness.normalized_sequence,
                    sequence_hash=seq_hash or sequence_hash(completeness.normalized_sequence),
                    length=len(completeness.normalized_sequence),
                    source=candidate.sequence_source,
                )
            )

        if not completeness.is_complete:
            protein.summary = completeness.reason
            self.session.commit()
            return protein

        evidence = await self._check_structure_evidence(protein)
        repository_evidence = await self.repositories.search_all(protein.name, protein.accession)
        self._persist_repository_evidence(protein, repository_evidence)

        analysis = analyze_sequence(completeness.normalized_sequence)
        feature_types = self._persist_features(protein, analysis)
        evidence_statuses = [item.status for item in evidence + repository_evidence]

        score = score_protein(protein, publication, feature_types, evidence_statuses)
        protein.score = score.score
        protein.score_components = score.components
        protein.summary = score.justification

        structural_found = any(item.status == "found" for item in evidence + repository_evidence)
        if protein.score >= get_settings().alert_score_threshold and not structural_found:
            alert = Alert(
                protein=protein,
                score=protein.score,
                reason=alert_reason(protein.score, structural_found),
                justification=score.justification,
                evidence_statement=EVIDENCE_STATEMENT,
                bases_consulted=sorted({item.source for item in evidence + repository_evidence}),
            )
            self.session.add(alert)

        self.session.commit()
        return protein

    async def _check_structure_evidence(self, protein: Protein) -> list[EvidenceResult]:
        checks = [
            await self.alphafold.check_accession(protein.accession),
            await self.rcsb.check_accession(protein.accession),
        ]
        for item in checks:
            self.session.add(
                StructureEvidence(
                    protein=protein,
                    source=item.source,
                    status=EvidenceStatus(item.status),
                    method=item.method,
                    identifier=item.identifier,
                    url=item.url,
                    confidence=item.confidence,
                    message=item.message,
                    raw_response=item.raw_response,
                )
            )
        self._persist_literature_evidence(protein)
        return checks

    def _persist_literature_evidence(self, protein: Protein) -> None:
        keywords = [
            "AlphaFold",
            "ColabFold",
            "structure prediction",
            "protein structure",
            "folding",
            "AI structure prediction",
        ]
        for keyword in keywords:
            query = f"{protein.name} {keyword}"
            self.session.add(
                LiteratureEvidence(
                    protein=protein,
                    query=query,
                    source="literature_search_queue",
                    status=EvidenceStatus.skipped,
                    title=None,
                    url=None,
                    raw_response={"message": "Queued interface; PubMed/arXiv deep query can be enabled per deployment."},
                )
            )

    def _persist_repository_evidence(self, protein: Protein, evidence: list[EvidenceResult]) -> None:
        for item in evidence:
            self.session.add(
                RepositoryEvidence(
                    protein=protein,
                    source=item.source,
                    query=protein.name,
                    status=EvidenceStatus(item.status),
                    identifier=item.identifier,
                    url=item.url,
                    raw_response=item.raw_response,
                )
            )

    def _persist_features(self, protein: Protein, analysis) -> set[str]:
        feature_types: set[str] = set()
        self.session.query(SequenceFeature).filter(SequenceFeature.protein_id == protein.id).delete()
        self.session.add(
            SequenceFeature(
                protein=protein,
                feature_type="molecular_weight",
                name="Molecular weight",
                start=None,
                end=None,
                score=analysis.molecular_weight,
                metadata_json={"unit": "Da"},
            )
        )
        for aa, count in analysis.amino_acid_composition.items():
            self.session.add(
                SequenceFeature(
                    protein=protein,
                    feature_type="composition",
                    name=aa,
                    start=None,
                    end=None,
                    score=float(count),
                    metadata_json={},
                )
            )
        for feature in analysis.features:
            feature_types.add(feature["feature_type"])
            self.session.add(
                SequenceFeature(
                    protein=protein,
                    feature_type=feature["feature_type"],
                    name=feature["name"],
                    start=feature.get("start"),
                    end=feature.get("end"),
                    score=feature.get("score"),
                    metadata_json=feature,
                )
            )
        self.session.add(
            SequenceFeature(
                protein=protein,
                feature_type="localization",
                name=analysis.metadata["cellular_location_prediction"],
                metadata_json=analysis.metadata,
            )
        )
        return feature_types

    def _upsert_publication(self, payload: PublicationIn) -> Publication:
        publication = None
        if payload.source_id:
            publication = self.session.scalar(
                select(Publication).where(
                    Publication.source == payload.source,
                    Publication.source_id == payload.source_id,
                )
            )
        if not publication and payload.doi:
            publication = self.session.scalar(select(Publication).where(Publication.doi == payload.doi))
        publication = publication or Publication(source=payload.source, source_id=payload.source_id, title=payload.title)
        publication.doi = payload.doi
        publication.title = payload.title
        publication.abstract = payload.abstract
        publication.journal = payload.journal
        publication.published_date = payload.published_date
        publication.url = payload.url
        publication.raw_metadata = payload.raw_metadata
        self.session.add(publication)
        self.session.flush()
        if not publication.authors and payload.authors:
            for ordinal, name in enumerate(payload.authors, start=1):
                self.session.add(Author(publication=publication, name=name, ordinal=ordinal))
        return publication

    def _upsert_organism(self, organism_name: str | None) -> Organism | None:
        if not organism_name:
            return None
        scientific = "Homo sapiens" if organism_name.lower() == "human" else organism_name
        organism = self.session.scalar(select(Organism).where(Organism.scientific_name == scientific))
        if organism:
            return organism
        organism = Organism(scientific_name=scientific, is_human=scientific.lower() == "homo sapiens")
        self.session.add(organism)
        self.session.flush()
        return organism


def run_once_sync(session: Session, lookback_days: int | None = None) -> dict[str, int]:
    return asyncio.run(PipelineRunner(session).run_once(lookback_days=lookback_days))

