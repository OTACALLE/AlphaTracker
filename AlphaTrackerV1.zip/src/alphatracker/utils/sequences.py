from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass

VALID_AA = set("ACDEFGHIKLMNPQRSTVWY")
AMBIGUOUS_AA = set("BXZJUO")
STOP = "*"

FASTA_RE = re.compile(r"(?m)^>(?P<header>[^\n\r]+)\r?\n(?P<body>(?:[A-Za-z*.-]+\s*)+)")
ACCESSION_RE = re.compile(r"\b(?:[OPQ][0-9][A-Z0-9]{3}[0-9]|[A-NR-Z][0-9][A-Z][A-Z0-9]{2}[0-9])\b")


@dataclass(frozen=True)
class CompletenessCheck:
    is_complete: bool
    reason: str
    normalized_sequence: str


def normalize_sequence(sequence: str) -> str:
    return re.sub(r"[^A-Za-z*]", "", sequence).upper()


def sequence_hash(sequence: str) -> str:
    return hashlib.sha256(normalize_sequence(sequence).encode("ascii")).hexdigest()


def parse_fasta_blocks(text: str) -> list[tuple[str, str]]:
    blocks: list[tuple[str, str]] = []
    for match in FASTA_RE.finditer(text or ""):
        header = match.group("header").strip()
        seq = normalize_sequence(match.group("body"))
        if seq:
            blocks.append((header, seq))
    return blocks


def extract_accessions(text: str) -> list[str]:
    return sorted(set(ACCESSION_RE.findall(text or "")))


def check_complete_protein(sequence: str | None) -> CompletenessCheck:
    if not sequence:
        return CompletenessCheck(False, "No amino-acid sequence was available.", "")

    seq = normalize_sequence(sequence)
    if len(seq) < 16:
        return CompletenessCheck(False, "Sequence is shorter than 16 amino acids.", seq)
    if seq.endswith(STOP):
        seq = seq[:-1]
    if STOP in seq:
        return CompletenessCheck(False, "Sequence contains an internal stop codon marker.", seq)
    invalid = set(seq) - VALID_AA - AMBIGUOUS_AA
    if invalid:
        return CompletenessCheck(False, f"Sequence contains invalid amino-acid symbols: {sorted(invalid)}.", seq)
    ambiguous_count = sum(1 for aa in seq if aa in AMBIGUOUS_AA)
    if ambiguous_count / len(seq) > 0.05:
        return CompletenessCheck(False, "More than 5% of residues are ambiguous.", seq)

    lower_markers = ["fragment", "partial", "truncated"]
    reason = "Sequence passes length, alphabet, ambiguity, and stop-codon checks."
    return CompletenessCheck(True, reason + f" Fragment markers checked: {', '.join(lower_markers)}.", seq)

