from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Any

import yaml
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="ALPHATRACKER_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    database_url: str = "sqlite:///./alphatracker.sqlite3"
    redis_url: str = "redis://localhost:6379/0"
    api_host: str = "0.0.0.0"
    api_port: int = 8000
    poll_interval_minutes: int = 60
    lookback_days: int = 2
    alert_score_threshold: float = 70.0
    ncbi_email: str | None = None
    ncbi_api_key: str | None = None
    github_token: str | None = None
    log_level: str = "INFO"
    source_config_path: Path = Field(default=Path("config/sources.yaml"))
    http_timeout_seconds: float = 30.0
    http_max_retries: int = 3
    cache_ttl_hours: int = 24


@lru_cache
def get_settings() -> Settings:
    return Settings()


@lru_cache
def get_source_config() -> dict[str, Any]:
    path = get_settings().source_config_path
    if not path.exists():
        return {}
    with path.open("r", encoding="utf-8") as handle:
        loaded = yaml.safe_load(handle) or {}
    return loaded

