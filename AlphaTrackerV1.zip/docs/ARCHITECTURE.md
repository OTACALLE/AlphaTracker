# Alpha Tracker Architecture

Alpha Tracker is organized as a modular scientific evidence system.

## Runtime

- FastAPI serves the dashboard API.
- Celery workers run continuous monitoring jobs.
- Celery Beat schedules monitoring every `ALPHATRACKER_POLL_INTERVAL_MINUTES`.
- PostgreSQL stores normalized entities and audit trails.
- Redis is the broker/result backend.
- React renders the operational dashboard.

## Scientific Guardrail

The system only reports evidence status for queried public sources. The absence of public evidence in these sources is not proof that no model exists.

Required wording:

```text
No public evidence of a structural model or corresponding structural publication was found in the queried sources.
```

## Pipeline

1. Fetch recent publication metadata.
2. Parse candidate protein names, accessions, organisms, and FASTA blocks.
3. Retrieve missing FASTA from NCBI Protein when an accession is available.
4. Validate sequence completeness.
5. Query structural evidence sources.
6. Search repository evidence sources.
7. Analyze sequence features.
8. Score and persist candidates.
9. Generate alerts above threshold.

## Extending Connectors

Every connector should return one of:

- `found`: public evidence was found.
- `not_found`: lookup succeeded and no matching evidence was found.
- `inconclusive`: lookup failed or response could not be interpreted.
- `skipped`: connector was intentionally not run.

Do not convert `inconclusive` to `not_found`.

